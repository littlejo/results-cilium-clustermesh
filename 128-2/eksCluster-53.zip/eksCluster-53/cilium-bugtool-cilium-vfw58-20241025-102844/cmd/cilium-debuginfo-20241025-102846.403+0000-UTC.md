# Cilium debug information

#### Cilium version

```
1.16.0 82999990 2024-07-23T22:22:14-07:00 go version go1.22.5 linux/arm64
```


#### Cilium status

```
KVStore:                Ok   Disabled
Kubernetes:             Ok   1.30+ (v1.30.5-eks-ce1d5eb) [linux/amd64]
Kubernetes APIs:        ["EndpointSliceOrEndpoint", "cilium/v2::CiliumClusterwideNetworkPolicy", "cilium/v2::CiliumEndpoint", "cilium/v2::CiliumNetworkPolicy", "cilium/v2::CiliumNode", "cilium/v2alpha1::CiliumCIDRGroup", "core/v1::Namespace", "core/v1::Pods", "core/v1::Service", "networking.k8s.io/v1::NetworkPolicy"]
KubeProxyReplacement:   False   
Host firewall:          Disabled
SRv6:                   Disabled
CNI Chaining:           none
CNI Config file:        successfully wrote CNI configuration file to /host/etc/cni/net.d/05-cilium.conflist
Cilium:                 Ok   1.16.0 (v1.16.0-82999990)
NodeMonitor:            Listening for events on 2 CPUs with 64x4096 of shared memory
Cilium health daemon:   Ok   
IPAM:                   IPv4: 5/254 allocated from 10.53.0.0/24, 
Allocated addresses:
  10.53.0.181 (router)
  10.53.0.195 (kube-system/clustermesh-apiserver-65c8447649-m6xtr)
  10.53.0.242 (kube-system/coredns-cc6ccd49c-m7f65)
  10.53.0.68 (health)
  10.53.0.89 (kube-system/coredns-cc6ccd49c-pn6vt)
ClusterMesh:   127/127 remote clusters ready, 0 global-services
   cmesh1: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=1, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh10: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=10, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh100: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=100, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh101: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=101, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh102: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=102, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh103: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=103, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh104: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=104, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh105: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=105, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh106: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=106, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh107: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=107, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh108: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=108, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh109: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=109, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh11: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=11, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh110: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=110, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh111: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=111, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh112: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=112, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh113: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=113, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh114: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=114, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh115: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=115, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh116: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=116, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh117: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=117, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh118: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=118, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh119: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=119, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh12: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=12, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh120: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=120, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh121: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=121, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh122: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=122, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh123: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=123, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh124: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=124, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh125: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=125, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh126: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=126, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh127: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=127, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh128: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=128, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh13: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=13, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh14: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=14, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh15: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=15, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh16: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=16, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh17: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=17, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh18: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=18, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh19: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=19, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh2: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=2, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh20: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=20, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh21: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=21, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh22: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=22, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh23: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=23, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh24: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=24, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh25: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=25, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh26: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=26, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh27: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=27, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh28: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=28, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh29: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=29, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh3: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=3, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh30: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=30, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh31: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=31, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh32: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=32, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh33: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=33, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh34: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=34, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh35: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=35, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh36: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=36, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh37: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=37, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh38: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=38, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh39: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=39, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh4: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=4, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh40: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=40, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh41: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=41, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh42: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=42, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh43: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=43, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh44: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=44, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh45: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=45, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh46: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=46, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh47: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=47, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh48: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=48, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh49: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=49, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh5: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=5, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh50: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=50, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh51: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=51, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh52: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=52, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh53: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=53, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh55: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=55, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh56: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=56, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh57: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=57, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh58: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=58, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh59: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=59, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh6: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=6, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh60: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=60, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh61: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=61, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh62: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=62, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh63: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=63, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh64: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=64, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh65: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=65, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh66: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=66, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh67: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=67, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh68: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=68, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh69: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=69, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh7: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=7, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh70: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=70, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh71: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=71, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh72: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=72, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh73: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=73, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh74: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=74, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh75: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=75, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh76: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=76, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh77: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=77, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh78: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=78, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh79: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=79, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh8: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=8, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh80: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=80, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh81: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=81, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh82: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=82, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh83: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=83, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh84: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=84, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh85: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=85, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh86: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=86, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh87: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=87, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh88: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=88, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh89: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=89, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh9: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=9, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh90: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=90, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh91: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=91, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh92: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=92, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh93: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=93, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh94: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=94, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh95: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=95, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh96: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=96, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh97: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=97, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh98: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=98, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
   cmesh99: ready, 1 nodes, 3 endpoints, 2 identities, 0 services, 0 reconnections (last: never)
   └  etcd: 1/1 connected, leases=0, lock leases=1, has-quorum=true: endpoint status checks are disabled, ID: bb215ed52459c861
   └  remote configuration: expected=true, retrieved=true, cluster-id=99, kvstoremesh=true, sync-canaries=true
   └  synchronization status: nodes=true, endpoints=true, identities=true, services=true
IPv4 BIG TCP:           Disabled
IPv6 BIG TCP:           Disabled
BandwidthManager:       Disabled
Routing:                Network: Tunnel [vxlan]   Host: Legacy
Attach Mode:            Legacy TC
Device Mode:            veth
Masquerading:           IPTables [IPv4: Enabled, IPv6: Disabled]
Clock Source for BPF:   ktime
Controller Status:      162/162 healthy
  Name                                                                Last success   Last error   Count   Message
  cilium-health-ep                                                    20s ago        never        0       no error   
  ct-map-pressure                                                     22s ago        never        0       no error   
  daemon-validate-config                                              8s ago         never        0       no error   
  dns-garbage-collector-job                                           24s ago        never        0       no error   
  endpoint-1077-regeneration-recovery                                 never          never        0       no error   
  endpoint-1488-regeneration-recovery                                 never          never        0       no error   
  endpoint-2999-regeneration-recovery                                 never          never        0       no error   
  endpoint-496-regeneration-recovery                                  never          never        0       no error   
  endpoint-978-regeneration-recovery                                  never          never        0       no error   
  endpoint-gc                                                         4m24s ago      never        0       no error   
  ep-bpf-prog-watchdog                                                22s ago        never        0       no error   
  ipcache-inject-labels                                               22s ago        never        0       no error   
  k8s-heartbeat                                                       24s ago        never        0       no error   
  link-cache                                                          7s ago         never        0       no error   
  local-identity-checkpoint                                           14m12s ago     never        0       no error   
  node-neighbor-link-updater                                          2s ago         never        0       no error   
  remote-etcd-cmesh1                                                  5m10s ago      never        0       no error   
  remote-etcd-cmesh10                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh100                                                5m10s ago      never        0       no error   
  remote-etcd-cmesh101                                                5m10s ago      never        0       no error   
  remote-etcd-cmesh102                                                5m10s ago      never        0       no error   
  remote-etcd-cmesh103                                                5m11s ago      never        0       no error   
  remote-etcd-cmesh104                                                5m10s ago      never        0       no error   
  remote-etcd-cmesh105                                                5m10s ago      never        0       no error   
  remote-etcd-cmesh106                                                5m10s ago      never        0       no error   
  remote-etcd-cmesh107                                                5m10s ago      never        0       no error   
  remote-etcd-cmesh108                                                5m10s ago      never        0       no error   
  remote-etcd-cmesh109                                                5m10s ago      never        0       no error   
  remote-etcd-cmesh11                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh110                                                5m10s ago      never        0       no error   
  remote-etcd-cmesh111                                                5m10s ago      never        0       no error   
  remote-etcd-cmesh112                                                5m10s ago      never        0       no error   
  remote-etcd-cmesh113                                                5m10s ago      never        0       no error   
  remote-etcd-cmesh114                                                5m10s ago      never        0       no error   
  remote-etcd-cmesh115                                                5m10s ago      never        0       no error   
  remote-etcd-cmesh116                                                5m11s ago      never        0       no error   
  remote-etcd-cmesh117                                                5m11s ago      never        0       no error   
  remote-etcd-cmesh118                                                5m10s ago      never        0       no error   
  remote-etcd-cmesh119                                                5m11s ago      never        0       no error   
  remote-etcd-cmesh12                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh120                                                5m10s ago      never        0       no error   
  remote-etcd-cmesh121                                                5m10s ago      never        0       no error   
  remote-etcd-cmesh122                                                5m10s ago      never        0       no error   
  remote-etcd-cmesh123                                                5m11s ago      never        0       no error   
  remote-etcd-cmesh124                                                5m10s ago      never        0       no error   
  remote-etcd-cmesh125                                                5m10s ago      never        0       no error   
  remote-etcd-cmesh126                                                5m10s ago      never        0       no error   
  remote-etcd-cmesh127                                                5m10s ago      never        0       no error   
  remote-etcd-cmesh128                                                5m10s ago      never        0       no error   
  remote-etcd-cmesh13                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh14                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh15                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh16                                                 5m11s ago      never        0       no error   
  remote-etcd-cmesh17                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh18                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh19                                                 5m11s ago      never        0       no error   
  remote-etcd-cmesh2                                                  5m10s ago      never        0       no error   
  remote-etcd-cmesh20                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh21                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh22                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh23                                                 5m11s ago      never        0       no error   
  remote-etcd-cmesh24                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh25                                                 5m11s ago      never        0       no error   
  remote-etcd-cmesh26                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh27                                                 5m11s ago      never        0       no error   
  remote-etcd-cmesh28                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh29                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh3                                                  5m10s ago      never        0       no error   
  remote-etcd-cmesh30                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh31                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh32                                                 5m11s ago      never        0       no error   
  remote-etcd-cmesh33                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh34                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh35                                                 5m11s ago      never        0       no error   
  remote-etcd-cmesh36                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh37                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh38                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh39                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh4                                                  5m10s ago      never        0       no error   
  remote-etcd-cmesh40                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh41                                                 5m11s ago      never        0       no error   
  remote-etcd-cmesh42                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh43                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh44                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh45                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh46                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh47                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh48                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh49                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh5                                                  5m11s ago      never        0       no error   
  remote-etcd-cmesh50                                                 5m11s ago      never        0       no error   
  remote-etcd-cmesh51                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh52                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh53                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh55                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh56                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh57                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh58                                                 5m11s ago      never        0       no error   
  remote-etcd-cmesh59                                                 5m11s ago      never        0       no error   
  remote-etcd-cmesh6                                                  5m10s ago      never        0       no error   
  remote-etcd-cmesh60                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh61                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh62                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh63                                                 5m11s ago      never        0       no error   
  remote-etcd-cmesh64                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh65                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh66                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh67                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh68                                                 5m11s ago      never        0       no error   
  remote-etcd-cmesh69                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh7                                                  5m10s ago      never        0       no error   
  remote-etcd-cmesh70                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh71                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh72                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh73                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh74                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh75                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh76                                                 5m11s ago      never        0       no error   
  remote-etcd-cmesh77                                                 5m11s ago      never        0       no error   
  remote-etcd-cmesh78                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh79                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh8                                                  5m11s ago      never        0       no error   
  remote-etcd-cmesh80                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh81                                                 5m11s ago      never        0       no error   
  remote-etcd-cmesh82                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh83                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh84                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh85                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh86                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh87                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh88                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh89                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh9                                                  5m10s ago      never        0       no error   
  remote-etcd-cmesh90                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh91                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh92                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh93                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh94                                                 5m11s ago      never        0       no error   
  remote-etcd-cmesh95                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh96                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh97                                                 5m11s ago      never        0       no error   
  remote-etcd-cmesh98                                                 5m10s ago      never        0       no error   
  remote-etcd-cmesh99                                                 5m10s ago      never        0       no error   
  resolve-identity-1077                                               1m30s ago      never        0       no error   
  resolve-identity-1488                                               4m21s ago      never        0       no error   
  resolve-identity-2999                                               4m22s ago      never        0       no error   
  resolve-identity-496                                                4m21s ago      never        0       no error   
  resolve-identity-978                                                4m20s ago      never        0       no error   
  resolve-labels-kube-system/clustermesh-apiserver-65c8447649-m6xtr   6m30s ago      never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-m7f65                  14m21s ago     never        0       no error   
  resolve-labels-kube-system/coredns-cc6ccd49c-pn6vt                  14m21s ago     never        0       no error   
  sync-lb-maps-with-k8s-services                                      14m22s ago     never        0       no error   
  sync-policymap-1077                                                 6m30s ago      never        0       no error   
  sync-policymap-1488                                                 14m16s ago     never        0       no error   
  sync-policymap-2999                                                 14m20s ago     never        0       no error   
  sync-policymap-496                                                  14m19s ago     never        0       no error   
  sync-policymap-978                                                  14m16s ago     never        0       no error   
  sync-to-k8s-ciliumendpoint (1077)                                   10s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (1488)                                   11s ago        never        0       no error   
  sync-to-k8s-ciliumendpoint (496)                                    11s ago        never        0       no error   
  sync-utime                                                          22s ago        never        0       no error   
  write-cni-file                                                      14m24s ago     never        0       no error   
Proxy Status:            OK, ip 10.53.0.181, 0 redirects active on ports 10000-20000, Envoy: external
Global Identity Range:   min 3538944, max 3604479
Hubble:                  Ok   Current/Max Flows: 4095/4095 (100.00%), Flows/s: 63.17   Metrics: Disabled
KubeProxyReplacement Details:
  Status:                 False
  Socket LB:              Disabled
  Socket LB Tracing:      Disabled
  Socket LB Coverage:     Full
  Session Affinity:       Disabled
  Graceful Termination:   Enabled
  NAT46/64 Support:       Disabled
  Services:
  - ClusterIP:      Enabled
  - NodePort:       Disabled 
  - LoadBalancer:   Disabled 
  - externalIPs:    Disabled 
  - HostPort:       Disabled
BPF Maps:   dynamic sizing: on (ratio: 0.002500)
  Name                          Size
  Auth                          524288
  Non-TCP connection tracking   65536
  TCP connection tracking       131072
  Endpoint policy               65535
  IP cache                      512000
  IPv4 masquerading agent       16384
  IPv6 masquerading agent       16384
  IPv4 fragmentation            8192
  IPv4 service                  65536
  IPv6 service                  65536
  IPv4 service backend          65536
  IPv6 service backend          65536
  IPv4 service reverse NAT      65536
  IPv6 service reverse NAT      65536
  Metrics                       1024
  NAT                           131072
  Neighbor table                131072
  Global policy                 16384
  Session affinity              65536
  Sock reverse NAT              65536
  Tunnel                        65536
Encryption:   Disabled   
```

#### Cilium environment keys

```
tofqdns-proxy-port:0
multicast-enabled:false
config-sources:config-map:kube-system/cilium-config
datapath-mode:veth
enable-ip-masq-agent:false
l2-announcements-lease-duration:15s
http-retry-timeout:0
bpf-lb-external-clusterip:false
hubble-export-file-path:
iptables-lock-timeout:5s
dnsproxy-lock-count:131
ipv4-service-loopback-address:169.254.42.1
enable-xt-socket-fallback:true
enable-nat46x64-gateway:false
ipam-multi-pool-pre-allocation:
enable-stale-cilium-endpoint-cleanup:true
bpf-ct-timeout-service-tcp:2h13m20s
enable-well-known-identities:false
lib-dir:/var/lib/cilium
enable-xdp-prefilter:false
k8s-watcher-endpoint-selector:metadata.name!=kube-scheduler,metadata.name!=kube-controller-manager,metadata.name!=etcd-operator,metadata.name!=gcp-controller-manager
enable-ipsec-key-watcher:true
hubble-tls-cert-file:/var/lib/cilium/tls/hubble/server.crt
auto-create-cilium-node-resource:true
ip-masq-agent-config-path:/etc/config/ip-masq-agent
proxy-gid:1337
enable-ipv6-masquerade:true
tofqdns-dns-reject-response-code:refused
enable-host-port:false
prometheus-serve-addr:
egress-gateway-policy-map-max:16384
socket-path:/var/run/cilium/cilium.sock
disable-external-ip-mitigation:false
dnsproxy-socket-linger-timeout:10
encrypt-node:false
bpf-lb-service-map-max:0
k8s-kubeconfig-path:
route-metric:0
ipv6-cluster-alloc-cidr:f00d::/64
identity-gc-interval:15m0s
use-cilium-internal-ip-for-ipsec:false
mesh-auth-gc-interval:5m0s
hubble-monitor-events:
conntrack-gc-max-interval:0s
vtep-mac:
disable-iptables-feeder-rules:
write-cni-conf-when-ready:/host/etc/cni/net.d/05-cilium.conflist
cni-exclusive:true
hubble-redact-http-userinfo:true
mtu:0
policy-queue-size:100
k8s-api-server:
cgroup-root:/run/cilium/cgroupv2
bpf-lb-source-range-map-max:0
bpf-ct-timeout-regular-tcp-fin:10s
direct-routing-device:
bpf-policy-map-full-reconciliation-interval:15m0s
hubble-socket-path:/var/run/cilium/hubble.sock
enable-pmtu-discovery:false
enable-service-topology:false
enable-ipv6-ndp:false
egress-multi-home-ip-rule-compat:false
bpf-sock-rev-map-max:262144
hubble-disable-tls:false
disable-endpoint-crd:false
annotate-k8s-node:false
ipam-cilium-node-update-rate:15s
certificates-directory:/var/run/cilium/certs
cluster-pool-ipv4-cidr:10.53.0.0/16
log-driver:
node-port-bind-protection:true
cni-chaining-target:
http-retry-count:3
hubble-event-buffer-capacity:4095
hubble-export-fieldmask:
cilium-endpoint-gc-interval:5m0s
bpf-lb-rss-ipv6-src-cidr:
ingress-secrets-namespace:
enable-gateway-api:false
mke-cgroup-mount:
envoy-base-id:0
operator-api-serve-addr:127.0.0.1:9234
gops-port:9890
tofqdns-endpoint-max-ip-per-hostname:50
hubble-export-file-compress:false
node-port-mode:snat
identity-heartbeat-timeout:30m0s
pprof-port:6060
bpf-auth-map-max:524288
max-connected-clusters:255
monitor-aggregation:medium
enable-sctp:false
policy-accounting:true
enable-srv6:false
enable-ipv4-egress-gateway:false
bgp-announce-pod-cidr:false
bpf-lb-algorithm:random
bpf-ct-global-tcp-max:524288
vtep-mask:
hubble-redact-http-urlquery:false
k8s-client-qps:10
bpf-ct-timeout-regular-tcp:2h13m20s
crd-wait-timeout:5m0s
k8s-sync-timeout:3m0s
cluster-name:cmesh54
bpf-ct-timeout-service-any:1m0s
agent-liveness-update-interval:1s
encryption-strict-mode-allow-remote-node-identities:false
cluster-pool-ipv4-mask-size:24
hubble-tls-client-ca-files:/var/lib/cilium/tls/hubble/client-ca.crt
enable-metrics:true
dns-policy-unload-on-shutdown:false
enable-active-connection-tracking:false
node-encryption-opt-out-labels:node-role.kubernetes.io/control-plane
enable-ingress-controller:false
mesh-auth-rotated-identities-queue-size:1024
k8s-require-ipv6-pod-cidr:false
bpf-lb-affinity-map-max:0
mesh-auth-mutual-connect-timeout:5s
exclude-local-address:
http-normalize-path:true
bpf-map-dynamic-size-ratio:0.0025
enable-endpoint-health-checking:true
http-max-grpc-timeout:0
enable-k8s-terminating-endpoint:true
enable-hubble-recorder-api:true
ipv4-service-range:auto
cmdref:
l2-pod-announcements-interface:
kvstore-max-consecutive-quorum-errors:2
endpoint-gc-interval:5m0s
node-port-acceleration:disabled
policy-trigger-interval:1s
enable-ipv6:false
identity-allocation-mode:crd
cni-external-routing:false
tofqdns-pre-cache:
enable-runtime-device-detection:true
tofqdns-max-deferred-connection-deletes:10000
use-full-tls-context:false
debug:false
enable-ipv4-big-tcp:false
enable-bpf-masquerade:false
hubble-metrics-server:
bpf-map-event-buffers:
enable-cilium-health-api-server-access:
ipsec-key-rotation-duration:5m0s
hubble-export-file-max-backups:5
enable-tracing:false
enable-ipv4-masquerade:true
read-cni-conf:
enable-auto-protect-node-port-range:true
enable-bandwidth-manager:false
envoy-keep-cap-netbindservice:false
nodeport-addresses:
ipv4-pod-subnets:
dnsproxy-concurrency-processing-grace-period:0s
l2-announcements-retry-period:2s
prepend-iptables-chains:true
enable-vtep:false
dnsproxy-enable-transparent-mode:true
iptables-random-fully:false
mesh-auth-signal-backoff-duration:1s
k8s-require-ipv4-pod-cidr:false
bgp-announce-lb-ip:false
bpf-lb-sock:false
max-internal-timer-delay:0s
kvstore-connectivity-timeout:2m0s
cni-chaining-mode:none
enable-l7-proxy:true
hubble-metrics:
ipv6-pod-subnets:
mesh-auth-spiffe-trust-domain:spiffe.cilium
bpf-nat-global-max:524288
bpf-root:/sys/fs/bpf
cluster-health-port:4240
enable-k8s-networkpolicy:true
clustermesh-sync-timeout:1m0s
enable-ipv4:true
enable-hubble:true
enable-node-port:false
egress-gateway-reconciliation-trigger-interval:1s
tofqdns-enable-dns-compression:true
k8s-client-burst:20
enable-health-check-nodeport:true
bpf-lb-maglev-table-size:16381
bgp-config-path:/var/lib/cilium/bgp/config.yaml
tofqdns-min-ttl:0
custom-cni-conf:false
dns-max-ips-per-restored-rule:1000
bpf-filter-priority:1
ipv4-range:auto
bpf-fragments-map-max:8192
envoy-secrets-namespace:
enable-ipsec-xfrm-state-caching:true
enable-node-selector-labels:false
conntrack-gc-interval:0s
enable-ipsec:false
identity-restore-grace-period:30s
labels:
envoy-config-retry-interval:15s
encryption-strict-mode-cidr:
clustermesh-config:/var/lib/cilium/clustermesh/
kube-proxy-replacement-healthz-bind-address:
hubble-prefer-ipv6:false
hubble-event-queue-size:0
auto-direct-node-routes:false
hubble-flowlogs-config-path:
bpf-lb-sock-terminate-pod-connections:false
unmanaged-pod-watcher-interval:15
proxy-xff-num-trusted-hops-ingress:0
enable-monitor:true
local-router-ipv6:
kube-proxy-replacement:false
pprof-address:localhost
max-controller-interval:0
mesh-auth-spire-admin-socket:
fixed-identity-mapping:
gateway-api-secrets-namespace:
bpf-lb-maglev-map-max:0
container-ip-local-reserved-ports:auto
proxy-prometheus-port:0
operator-prometheus-serve-addr::9963
log-system-load:false
proxy-xff-num-trusted-hops-egress:0
debug-verbose:
ipv6-node:auto
k8s-heartbeat-timeout:30s
bpf-lb-maglev-hash-seed:JLfvgnHc2kaSUFaI
tofqdns-idle-connection-grace-period:0s
version:false
trace-sock:true
hubble-drop-events:false
external-envoy-proxy:true
enable-unreachable-routes:false
bpf-events-policy-verdict-enabled:true
envoy-config-timeout:2m0s
policy-audit-mode:false
enable-session-affinity:false
set-cilium-is-up-condition:true
fqdn-regex-compile-lru-size:1024
enable-policy:default
policy-cidr-match-mode:
enable-k8s-api-discovery:false
tunnel-protocol:vxlan
enable-ipip-termination:false
vtep-cidr:
hubble-export-denylist:
bpf-node-map-max:16384
enable-cilium-api-server-access:
enable-icmp-rules:true
bpf-events-drop-enabled:true
dnsproxy-insecure-skip-transparent-mode-check:false
local-router-ipv4:
monitor-aggregation-flags:all
bpf-ct-timeout-regular-tcp-syn:1m0s
egress-masquerade-interfaces:ens+
bpf-lb-acceleration:disabled
bpf-policy-map-max:16384
hubble-export-file-max-size-mb:10
ipsec-key-file:
agent-labels:
bpf-lb-sock-hostns-only:false
k8s-client-connection-keep-alive:30s
bpf-lb-mode:snat
kvstore-lease-ttl:15m0s
enable-ipv4-fragment-tracking:true
allow-localhost:auto
mesh-auth-enabled:true
enable-tcx:true
mesh-auth-mutual-listener-port:0
clustermesh-ip-identities-sync-timeout:1m0s
cni-log-file:/var/run/cilium/cilium-cni.log
enable-external-ips:false
service-no-backend-response:reject
ipv4-native-routing-cidr:
l2-announcements-renew-deadline:5s
label-prefix-file:
enable-bpf-clock-probe:false
pprof:false
enable-wireguard:false
k8s-client-connection-timeout:30s
set-cilium-node-taints:true
nat-map-stats-entries:32
wireguard-persistent-keepalive:0s
enable-route-mtu-for-cni-chaining:false
config-dir:/tmp/cilium/config-map
remove-cilium-node-taints:true
node-labels:
ipv4-node:auto
cluster-id:54
disable-envoy-version-check:false
tunnel-port:0
bpf-lb-dsr-dispatch:opt
kvstore:
enable-ipv6-big-tcp:false
k8s-namespace:kube-system
arping-refresh-period:30s
srv6-encap-mode:reduced
state-dir:/var/run/cilium
enable-mke:false
ipv6-range:auto
procfs:/host/proc
enable-bgp-control-plane:false
hubble-redact-kafka-apikey:false
monitor-aggregation-interval:5s
bpf-events-trace-enabled:true
enable-masquerade-to-route-source:false
enable-identity-mark:true
cflags:
vtep-endpoint:
enable-l2-announcements:false
enable-envoy-config:false
config:
bpf-ct-global-any-max:262144
bpf-neigh-global-max:524288
encrypt-interface:
enable-l2-neigh-discovery:true
bpf-lb-map-max:65536
hubble-recorder-sink-queue-size:1024
enable-health-checking:true
dnsproxy-lock-timeout:500ms
proxy-connect-timeout:2
install-no-conntrack-iptables-rules:false
proxy-admin-port:0
ipv6-mcast-device:
log-opt:
enable-k8s-endpoint-slice:true
enable-k8s:true
hubble-export-allowlist:
hubble-tls-key-file:/var/lib/cilium/tls/hubble/server.key
bpf-lb-service-backend-map-max:0
direct-routing-skip-unreachable:false
proxy-max-connection-duration-seconds:0
bpf-lb-rev-nat-map-max:0
agent-health-port:9879
dnsproxy-concurrency-limit:0
enable-host-firewall:false
install-iptables-rules:true
monitor-queue-size:0
metrics:
proxy-max-requests-per-connection:0
enable-local-redirect-policy:false
ipv6-service-range:auto
controller-group-metrics:
enable-svc-source-range-check:true
enable-local-node-route:true
hubble-drop-events-interval:2m0s
trace-payloadlen:128
enable-endpoint-routes:false
endpoint-bpf-prog-watchdog-interval:30s
clustermesh-enable-endpoint-sync:false
envoy-log:
enable-wireguard-userspace-fallback:false
enable-ipsec-encrypted-overlay:false
bpf-lb-rss-ipv4-src-cidr:
ipv6-native-routing-cidr:
http-idle-timeout:0
derive-masq-ip-addr-from-device:
keep-config:false
local-max-addr-scope:252
api-rate-limit:
hubble-redact-enabled:false
proxy-portrange-max:20000
routing-mode:tunnel
enable-health-check-loadbalancer-ip:false
ipam:cluster-pool
nodes-gc-interval:5m0s
static-cnp-path:
restore:true
join-cluster:false
bpf-ct-timeout-service-tcp-grace:1m0s
force-device-detection:false
bpf-lb-dsr-l4-xlate:frontend
hubble-recorder-storage-path:/var/run/cilium/pcaps
k8s-service-proxy-name:
devices:
bypass-ip-availability-upon-restore:false
hubble-redact-http-headers-allow:
ipam-default-ip-pool:default
k8s-service-cache-size:128
hubble-redact-http-headers-deny:
allow-icmp-frag-needed:true
tofqdns-proxy-response-max-delay:100ms
synchronize-k8s-nodes:true
enable-cilium-endpoint-slice:false
enable-custom-calls:false
hubble-drop-events-reasons:auth_required,policy_denied
enable-l2-pod-announcements:false
exclude-node-label-patterns:
hubble-skip-unknown-cgroup-ids:true
enable-bpf-tproxy:false
endpoint-queue-size:25
preallocate-bpf-maps:false
nat-map-stats-interval:30s
node-port-algorithm:random
enable-high-scale-ipcache:false
enable-host-legacy-routing:false
kvstore-opt:
enable-bbr:false
node-port-range:
identity-change-grace-period:5s
proxy-idle-timeout-seconds:60
kvstore-periodic-sync:5m0s
vlan-bpf-bypass:
proxy-portrange-min:10000
allocator-list-timeout:3m0s
enable-encryption-strict-mode:false
bpf-ct-timeout-regular-any:1m0s
http-request-timeout:3600
enable-recorder:false
clustermesh-enable-mcs-api:false
hubble-listen-address::4244
agent-not-ready-taint-key:node.cilium.io/agent-not-ready
mesh-auth-queue-size:1024
```


#### Endpoint list

```
ENDPOINT   POLICY (ingress)   POLICY (egress)   IDENTITY   LABELS (source:key[=value])                                                  IPv6   IPv4          STATUS   
           ENFORCEMENT        ENFORCEMENT                                                                                                                    
496        Disabled           Disabled          3582731    k8s:eks.amazonaws.com/component=coredns                                             10.53.0.89    ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh54                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
978        Disabled           Disabled          4          reserved:health                                                                     10.53.0.68    ready   
1077       Disabled           Disabled          3604221    k8s:app.kubernetes.io/name=clustermesh-apiserver                                    10.53.0.195   ready   
                                                           k8s:app.kubernetes.io/part-of=cilium                                                                      
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh54                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver                                             
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=clustermesh-apiserver                                                                         
1488       Disabled           Disabled          3582731    k8s:eks.amazonaws.com/component=coredns                                             10.53.0.242   ready   
                                                           k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system                                
                                                           k8s:io.cilium.k8s.policy.cluster=cmesh54                                                                  
                                                           k8s:io.cilium.k8s.policy.serviceaccount=coredns                                                           
                                                           k8s:io.kubernetes.pod.namespace=kube-system                                                               
                                                           k8s:k8s-app=kube-dns                                                                                      
2999       Disabled           Disabled          1          k8s:node.kubernetes.io/instance-type=t4g.medium                                                   ready   
                                                           k8s:topology.k8s.aws/zone-id=euw3-az2                                                                     
                                                           k8s:topology.kubernetes.io/region=eu-west-3                                                               
                                                           k8s:topology.kubernetes.io/zone=eu-west-3b                                                                
                                                           reserved:host                                                                                             
```

#### BPF Policy Get 496

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    65236   586       0        
Allow    Ingress     1          ANY          NONE         disabled    81162   935       0        
Allow    Egress      0          ANY          NONE         disabled    28364   280       0        

```


#### BPF CT List 496

```
Invalid argument: unknown type 496
```


#### Endpoint Get 496

```
[
  {
    "id": 496,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-496-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "3d8e8436-a040-43cd-a139-af15d55ee1e4"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-496",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:24.525Z",
            "success-count": 3
          },
          "uuid": "7f1fe925-6cf8-4420-9fe0-3e64d2e4fceb"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-pn6vt",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:24.522Z",
            "success-count": 1
          },
          "uuid": "6f298122-b2f2-4a90-9247-d731d288a6c2"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-496",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:26.670Z",
            "success-count": 1
          },
          "uuid": "4aa98191-ccd1-442e-b972-2cc6e3fce018"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (496)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:44.611Z",
            "success-count": 88
          },
          "uuid": "ab359f87-87fa-43a4-a8cb-06c3a6fb1bc9"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "b1c91b26e9ecce2e18118ac930eacd0d826be89d268b7abf0f3407db35831190:eth0",
        "container-id": "b1c91b26e9ecce2e18118ac930eacd0d826be89d268b7abf0f3407db35831190",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-pn6vt",
        "pod-name": "kube-system/coredns-cc6ccd49c-pn6vt"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3582731,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh54",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh54",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:37Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.53.0.89",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "2a:a2:7f:2c:4c:39",
        "interface-index": 9,
        "interface-name": "lxcc567fa974ade",
        "mac": "4e:01:38:32:e4:8c"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3582731,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3582731,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 496

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 496

```
Timestamp              Status    State                   Message
2024-10-25T10:23:37Z   OK        ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:37Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:37Z   OK        regenerating            Regenerating endpoint: 
2024-10-25T10:23:37Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:36Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:36Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:36Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:36Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:35Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:35Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:35Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:35Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:09Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:09Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:09Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:09Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:08Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:08Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:08Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:08Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:30Z   OK        ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:30Z   OK        ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:29Z   OK        regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:27Z   OK        waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:26Z   OK        waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:25Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:24Z   OK        regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:24Z   OK        waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:24Z   OK        ready                   Set identity for this endpoint
2024-10-25T10:14:24Z   Warning   waiting-for-identity    Skipped invalid state transition to waiting-to-regenerate due to: Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:24Z   OK        waiting-for-identity    Endpoint creation

```


#### Identity get 3582731

```
ID        LABELS
3582731   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh54
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 978

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    388810   4958      0        
Allow    Ingress     1          ANY          NONE         disabled    11592    134       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        

```


#### BPF CT List 978

```
Invalid argument: unknown type 978
```


#### Endpoint Get 978

```
[
  {
    "id": 978,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-978-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "22391a59-e04f-4dea-9e5d-6eda772971a6"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-978",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:25.430Z",
            "success-count": 3
          },
          "uuid": "c4ffc545-3315-4090-b595-3da4e730fec0"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-978",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:29.991Z",
            "success-count": 1
          },
          "uuid": "7b139d56-4d52-4526-a8d5-ad6dbae3a0fd"
        }
      ],
      "external-identifiers": {
        "container-name": "cilium-health",
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 4,
        "labels": [
          "reserved:health"
        ]
      },
      "labels": {
        "realized": {},
        "security-relevant": [
          "reserved:health"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:37Z"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.53.0.68",
            "ipv4-pool-name": "default"
          }
        ],
        "host-mac": "02:94:38:ac:33:f3",
        "interface-index": 7,
        "interface-name": "lxc_health",
        "mac": "72:af:51:d7:2a:26"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 4,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 978

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 978

```
Timestamp              Status   State                   Message
2024-10-25T10:23:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:37Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:36Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:35Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:29Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:29Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:28Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:27Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:25Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:14:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:25Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:24Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 4

```
ID   LABELS
4    reserved:health

```


#### BPF Policy Get 1077

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3182364   31375     0        
Allow    Ingress     1          ANY          NONE         disabled    2576417   25483     0        
Allow    Egress      0          ANY          NONE         disabled    3715294   35841     0        

```


#### BPF CT List 1077

```
Invalid argument: unknown type 1077
```


#### Endpoint Get 1077

```
[
  {
    "id": 1077,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1077-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "62cad365-a3de-487b-8924-dcf28b01e30b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1077",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:27:15.686Z",
            "success-count": 2
          },
          "uuid": "f939da41-384e-432f-976b-d8b6c3096b02"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/clustermesh-apiserver-65c8447649-m6xtr",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:15.680Z",
            "success-count": 1
          },
          "uuid": "06ffdf14-a1fd-4b0e-95cc-76e34855f054"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1077",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:22:15.714Z",
            "success-count": 1
          },
          "uuid": "3c70257b-e6a6-455b-963d-fd329ca92730"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1077)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:45.730Z",
            "success-count": 41
          },
          "uuid": "63681b3e-c2e1-40e8-8b3d-158c76828a8d"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "34709123e9c2c2fcc95e25b1eaae933ef204377374f16394eae41fbe6cb498b8:eth0",
        "container-id": "34709123e9c2c2fcc95e25b1eaae933ef204377374f16394eae41fbe6cb498b8",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "clustermesh-apiserver-65c8447649-m6xtr",
        "pod-name": "kube-system/clustermesh-apiserver-65c8447649-m6xtr"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3604221,
        "labels": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh54",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=65c8447649"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:app.kubernetes.io/name=clustermesh-apiserver",
          "k8s:app.kubernetes.io/part-of=cilium",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh54",
          "k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=clustermesh-apiserver"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:37Z"
        }
      ],
      "namedPorts": [
        {
          "name": "apiserv-health",
          "port": 9880,
          "protocol": "TCP"
        },
        {
          "name": "apiserv-metrics",
          "port": 9962,
          "protocol": "TCP"
        },
        {
          "name": "etcd",
          "port": 2379,
          "protocol": "TCP"
        },
        {
          "name": "etcd-metrics",
          "port": 9963,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-health",
          "port": 9881,
          "protocol": "TCP"
        },
        {
          "name": "kvmesh-metrics",
          "port": 9964,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.53.0.195",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "c2:9c:d1:31:52:76",
        "interface-index": 15,
        "interface-name": "lxc746a1f859e3f",
        "mac": "0e:ae:e0:a2:5f:8b"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3604221,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3604221,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1077

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1077

```
Timestamp              Status   State                   Message
2024-10-25T10:23:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:37Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:36Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:35Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:22:15Z   OK       ready                   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:22:15Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:22:15Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:22:15Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:22:15Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:22:15Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 3604221

```
ID        LABELS
3604221   k8s:app.kubernetes.io/name=clustermesh-apiserver
          k8s:app.kubernetes.io/part-of=cilium
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh54
          k8s:io.cilium.k8s.policy.serviceaccount=clustermesh-apiserver
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=clustermesh-apiserver

```


#### BPF Policy Get 1488

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    68882   621       0        
Allow    Ingress     1          ANY          NONE         disabled    80999   930       0        
Allow    Egress      0          ANY          NONE         disabled    29201   288       0        

```


#### BPF CT List 1488

```
Invalid argument: unknown type 1488
```


#### Endpoint Get 1488

```
[
  {
    "id": 1488,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-1488-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "92fbbd5e-f225-48bf-a85e-9d31f53af04e"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-1488",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:25.049Z",
            "success-count": 3
          },
          "uuid": "7f88d5ae-0720-4597-a300-74897f7540c0"
        },
        {
          "configuration": {
            "error-retry": true
          },
          "name": "resolve-labels-kube-system/coredns-cc6ccd49c-m7f65",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:25.047Z",
            "success-count": 1
          },
          "uuid": "5a984ceb-2476-4a6c-a4df-2be7e1f1125f"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-1488",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:29.992Z",
            "success-count": 1
          },
          "uuid": "613c9901-9e2e-43b7-a7a1-83b652d619ae"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "10s"
          },
          "name": "sync-to-k8s-ciliumendpoint (1488)",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:28:45.137Z",
            "success-count": 88
          },
          "uuid": "e7924923-492a-4402-95f6-fb7d515686d2"
        }
      ],
      "external-identifiers": {
        "cni-attachment-id": "fe31e90305cb30342daa99ca3923e6c21b3cdba5312e72e7d1849db406865d34:eth0",
        "container-id": "fe31e90305cb30342daa99ca3923e6c21b3cdba5312e72e7d1849db406865d34",
        "k8s-namespace": "kube-system",
        "k8s-pod-name": "coredns-cc6ccd49c-m7f65",
        "pod-name": "kube-system/coredns-cc6ccd49c-m7f65"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 3582731,
        "labels": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh54",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "labels": {
        "derived": [
          "k8s:pod-template-hash=cc6ccd49c"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:eks.amazonaws.com/component=coredns",
          "k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system",
          "k8s:io.cilium.k8s.policy.cluster=cmesh54",
          "k8s:io.cilium.k8s.policy.serviceaccount=coredns",
          "k8s:io.kubernetes.pod.namespace=kube-system",
          "k8s:k8s-app=kube-dns"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:37Z"
        }
      ],
      "namedPorts": [
        {
          "name": "dns",
          "port": 53,
          "protocol": "UDP"
        },
        {
          "name": "dns-tcp",
          "port": 53,
          "protocol": "TCP"
        },
        {
          "name": "metrics",
          "port": 9153,
          "protocol": "TCP"
        }
      ],
      "networking": {
        "addressing": [
          {
            "ipv4": "10.53.0.242",
            "ipv4-pool-name": "default"
          }
        ],
        "container-interface-name": "eth0",
        "host-mac": "2e:cb:04:4e:94:85",
        "interface-index": 11,
        "interface-name": "lxcc5473fc01db8",
        "mac": "1a:ad:1a:bd:23:27"
      },
      "policy": {
        "proxy-policy-revision": 1,
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3582731,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0,
            1
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 3582731,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 1488

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 1488

```
Timestamp              Status   State                   Message
2024-10-25T10:23:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:37Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:36Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:35Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:30Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:29Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:27Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level rewrite+load trigger due to devices changed
2024-10-25T10:14:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:25Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:25Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:25Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:25Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 3582731

```
ID        LABELS
3582731   k8s:eks.amazonaws.com/component=coredns
          k8s:io.cilium.k8s.namespace.labels.kubernetes.io/metadata.name=kube-system
          k8s:io.cilium.k8s.policy.cluster=cmesh54
          k8s:io.cilium.k8s.policy.serviceaccount=coredns
          k8s:io.kubernetes.pod.namespace=kube-system
          k8s:k8s-app=kube-dns

```


#### BPF Policy Get 2999

```
POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        

```


#### BPF CT List 2999

```
Invalid argument: unknown type 2999
```


#### Endpoint Get 2999

```
[
  {
    "id": 2999,
    "spec": {
      "label-configuration": {},
      "options": {
        "ConntrackAccounting": "Disabled",
        "ConntrackLocal": "Disabled",
        "Debug": "Disabled",
        "DebugLB": "Disabled",
        "DebugPolicy": "Disabled",
        "DropNotification": "Enabled",
        "MonitorAggregationLevel": "Medium",
        "PolicyAccounting": "Enabled",
        "PolicyAuditMode": "Disabled",
        "PolicyVerdictNotification": "Enabled",
        "SourceIPVerification": "Enabled",
        "TraceNotification": "Enabled"
      }
    },
    "status": {
      "controllers": [
        {
          "configuration": {
            "error-retry": true,
            "error-retry-base": "2s"
          },
          "name": "endpoint-2999-regeneration-recovery",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "0001-01-01T00:00:00.000Z"
          },
          "uuid": "028100d5-c160-43c5-bd64-a9c8e2193e5b"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "5m0s"
          },
          "name": "resolve-identity-2999",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:24:24.305Z",
            "success-count": 3
          },
          "uuid": "a3a200d5-1232-4480-b710-1fc7db791b20"
        },
        {
          "configuration": {
            "error-retry": true,
            "interval": "15m0s"
          },
          "name": "sync-policymap-2999",
          "status": {
            "last-failure-timestamp": "0001-01-01T00:00:00.000Z",
            "last-success-timestamp": "2024-10-25T10:14:25.425Z",
            "success-count": 1
          },
          "uuid": "0faef6fb-61b1-4e93-85d5-b5ea64642a71"
        }
      ],
      "external-identifiers": {
        "pod-name": "/"
      },
      "health": {
        "bpf": "OK",
        "connected": true,
        "overallHealth": "OK",
        "policy": "OK"
      },
      "identity": {
        "id": 1,
        "labels": [
          "reserved:host",
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b"
        ]
      },
      "labels": {
        "derived": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ],
        "realized": {},
        "security-relevant": [
          "k8s:node.kubernetes.io/instance-type=t4g.medium",
          "k8s:topology.k8s.aws/zone-id=euw3-az2",
          "k8s:topology.kubernetes.io/region=eu-west-3",
          "k8s:topology.kubernetes.io/zone=eu-west-3b",
          "reserved:host"
        ]
      },
      "log": [
        {
          "code": "OK",
          "message": "Successfully regenerated endpoint program (Reason: )",
          "state": "ready",
          "timestamp": "2024-10-25T10:23:37Z"
        }
      ],
      "networking": {
        "addressing": [
          {}
        ],
        "host-mac": "3e:96:36:15:7e:10",
        "interface-name": "cilium_host",
        "mac": "3e:96:36:15:7e:10"
      },
      "policy": {
        "proxy-statistics": [],
        "realized": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        },
        "spec": {
          "allowed-egress-identities": [
            0
          ],
          "allowed-ingress-identities": [
            0
          ],
          "build": 1,
          "denied-egress-identities": null,
          "denied-ingress-identities": null,
          "id": 1,
          "l4": {
            "egress": [],
            "ingress": []
          },
          "policy-enabled": "none",
          "policy-revision": 1
        }
      },
      "realized": {
        "label-configuration": {},
        "options": {
          "ConntrackAccounting": "Disabled",
          "ConntrackLocal": "Disabled",
          "Debug": "Disabled",
          "DebugLB": "Disabled",
          "DebugPolicy": "Disabled",
          "DropNotification": "Enabled",
          "MonitorAggregationLevel": "Medium",
          "PolicyAccounting": "Enabled",
          "PolicyAuditMode": "Disabled",
          "PolicyVerdictNotification": "Enabled",
          "SourceIPVerification": "Enabled",
          "TraceNotification": "Enabled"
        }
      },
      "state": "ready"
    }
  }
]


```


#### Endpoint Health 2999

```
Overall Health:   OK
BPF Health:       OK
Policy Health:    OK
Connected:        yes

```


#### Endpoint Log 2999

```
Timestamp              Status   State                   Message
2024-10-25T10:23:37Z   OK       ready                   Successfully regenerated endpoint program (Reason: )
2024-10-25T10:23:37Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:37Z   OK       regenerating            Regenerating endpoint: 
2024-10-25T10:23:37Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to 
2024-10-25T10:23:36Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:36Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:36Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:36Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:23:35Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:23:35Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:23:35Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:23:35Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:09Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:09Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:09Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:09Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:15:08Z   OK       ready                   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:15:08Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:15:08Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:15:08Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:30Z   OK       ready                   Successfully regenerated endpoint program (Reason: devices changed)
2024-10-25T10:14:30Z   OK       ready                   Completed endpoint regeneration with no pending regeneration requests
2024-10-25T10:14:29Z   OK       regenerating            Regenerating endpoint: devices changed
2024-10-25T10:14:28Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: one or more identities created or deleted)
2024-10-25T10:14:27Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to devices changed
2024-10-25T10:14:26Z   OK       regenerating            Regenerating endpoint: one or more identities created or deleted
2024-10-25T10:14:25Z   OK       waiting-to-regenerate   Skipped duplicate endpoint regeneration level no-rebuild trigger due to one or more identities created or deleted
2024-10-25T10:14:25Z   OK       waiting-to-regenerate   Successfully regenerated endpoint program (Reason: updated security labels)
2024-10-25T10:14:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to one or more identities created or deleted
2024-10-25T10:14:24Z   OK       regenerating            Regenerating endpoint: updated security labels
2024-10-25T10:14:24Z   OK       waiting-to-regenerate   Triggering endpoint regeneration due to updated security labels
2024-10-25T10:14:24Z   OK       ready                   Set identity for this endpoint
2024-10-25T10:14:24Z   OK       waiting-for-identity    Endpoint creation

```


#### Identity get 1

```
ID   LABELS
1    reserved:host

```


#### Policy get

```
:
 []
Revision: 1

```


#### ipam

```
(string) (len=6) "owners"
(map[ipam.Pool]map[string]string) (len=1) {
 (ipam.Pool) (len=7) default: (map[string]string) (len=5) {
  (string) (len=11) "10.53.0.181": (string) (len=6) "router",
  (string) (len=10) "10.53.0.68": (string) (len=6) "health",
  (string) (len=10) "10.53.0.89": (string) (len=35) "kube-system/coredns-cc6ccd49c-pn6vt",
  (string) (len=11) "10.53.0.242": (string) (len=35) "kube-system/coredns-cc6ccd49c-m7f65",
  (string) (len=11) "10.53.0.195": (string) (len=50) "kube-system/clustermesh-apiserver-65c8447649-m6xtr"
 }
}
(string) (len=17) "expiration timers"
(map[ipam.timerKey]ipam.expirationTimer) {
}
(string) (len=12) "excluded ips"
(map[string]string) (len=1) {
 (string) (len=22) "default:172.31.222.147": (string) (len=7) "node-ip"
}

```


#### k8s-service-cache

```
(*k8s.ServiceCache)(0x4001fec160)({
 config: (k8s.ServiceCacheConfig) {
  EnableServiceTopology: (bool) false
 },
 Events: (<-chan k8s.ServiceEvent) (cap=128) 0x4001f9ca80,
 sendEvents: (chan<- k8s.ServiceEvent) (cap=128) 0x4001f9ca80,
 notifications: (stream.FuncObservable[github.com/cilium/cilium/pkg/k8s.ServiceNotification]) 0x1d53fb0,
 emitNotifications: (func(k8s.ServiceNotification)) 0x1d54890,
 completeNotifications: (func(error)) 0x1d54610,
 mutex: (lock.RWMutex) {
  internalRWMutex: (lock.internalRWMutex) {
   RWMutex: (sync.RWMutex) {
    w: (sync.Mutex) {
     state: (int32) 0,
     sema: (uint32) 0
    },
    writerSem: (uint32) 0,
    readerSem: (uint32) 0,
    readerCount: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 1
    },
    readerWait: (atomic.Int32) {
     _: (atomic.noCopy) {
     },
     v: (int32) 0
    }
   }
  }
 },
 services: (map[k8s.ServiceID]*k8s.Service) (len=5) {
  (k8s.ServiceID) default/kubernetes: (*k8s.Service)(0x4001fec4d0)(frontends:[10.100.0.1]/ports=[https]/selector=map[]),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.Service)(0x4001fec580)(frontends:[10.100.203.172]/ports=[peer-service]/selector=map[k8s-app:cilium]),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.Service)(0x4001fec630)(frontends:[10.100.0.10]/ports=[metrics dns dns-tcp]/selector=map[k8s-app:kube-dns]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver-metrics: (*k8s.Service)(0x4001f23550)(frontends:[]/ports=[etcd-metrics apiserv-metrics kvmesh-metrics]/selector=map[k8s-app:clustermesh-apiserver]),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.Service)(0x4002db0630)(frontends:[10.100.128.104]/ports=[]/selector=map[k8s-app:clustermesh-apiserver])
 },
 endpoints: (map[k8s.ServiceID]*k8s.EndpointSlices) (len=4) {
  (k8s.ServiceID) default/kubernetes: (*k8s.EndpointSlices)(0x4001230838)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=10) "kubernetes": (*k8s.Endpoints)(0x4003813ad0)(172.31.133.231:443/TCP,172.31.248.73:443/TCP)
   }
  }),
  (k8s.ServiceID) kube-system/hubble-peer: (*k8s.EndpointSlices)(0x4001230840)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=17) "hubble-peer-gmsqm": (*k8s.Endpoints)(0x4002033110)(172.31.222.147:4244/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/kube-dns: (*k8s.EndpointSlices)(0x4001230848)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=14) "kube-dns-2h2j2": (*k8s.Endpoints)(0x40032004e0)(10.53.0.242:53/TCP[eu-west-3b],10.53.0.242:53/UDP[eu-west-3b],10.53.0.242:9153/TCP[eu-west-3b],10.53.0.89:53/TCP[eu-west-3b],10.53.0.89:53/UDP[eu-west-3b],10.53.0.89:9153/TCP[eu-west-3b])
   }
  }),
  (k8s.ServiceID) kube-system/clustermesh-apiserver: (*k8s.EndpointSlices)(0x400133b268)({
   epSlices: (map[string]*k8s.Endpoints) (len=1) {
    (string) (len=27) "clustermesh-apiserver-nfjrt": (*k8s.Endpoints)(0x400104f930)(10.53.0.195:2379/TCP[eu-west-3b])
   }
  })
 },
 externalEndpoints: (map[k8s.ServiceID]k8s.externalEndpoints) {
 },
 selfNodeZoneLabel: (string) "",
 ServiceMutators: ([]func(*v1.Service, *k8s.Service)) <nil>,
 db: (*statedb.DB)(0x4001920d20)({
  mu: (sync.Mutex) {
   state: (int32) 0,
   sema: (uint32) 0
  },
  ctx: (*context.cancelCtx)(0x400220cf50)(context.Background.WithCancel),
  cancel: (context.CancelFunc) 0xba580,
  root: (atomic.Pointer[[]github.com/cilium/statedb.tableEntry]) {
   _: ([0]*[]statedb.tableEntry) {
   },
   _: (atomic.noCopy) {
   },
   v: (unsafe.Pointer) 0x400a6149d8
  },
  gcTrigger: (chan struct {}) (cap=1) 0x400221c1e0,
  gcExited: (chan struct {}) 0x400221c240,
  gcRateLimitInterval: (time.Duration) 1s,
  metrics: (hive.stateDBMetricsImpl) {
   m: (hive.StateDBMetrics) {
    WriteTxnDuration: (*metric.histogramVec)(0x4001b2aa00)({
     ObserverVec: (*prometheus.HistogramVec)(0x40012e77f8)({
      MetricVec: (*prometheus.MetricVec)(0x4001c44db0)({
       metricMap: (*prometheus.metricMap)(0x4001c44de0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001997260)(Desc{fqName: "cilium_statedb_write_txn_duration_seconds", help: "How long a write transaction was held.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=26) "write_txn_duration_seconds",
       Help: (string) (len=38) "How long a write transaction was held.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    WriteTxnAcquisition: (*metric.histogramVec)(0x4001b2aa80)({
     ObserverVec: (*prometheus.HistogramVec)(0x40012e7800)({
      MetricVec: (*prometheus.MetricVec)(0x4001c44e40)({
       metricMap: (*prometheus.metricMap)(0x4001c44e70)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019972c0)(Desc{fqName: "cilium_statedb_write_txn_acquisition_seconds", help: "How long it took to acquire a write transaction for all tables.", constLabels: {}, variableLabels: {tables,handle}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "write_txn_acquisition_seconds",
       Help: (string) (len=63) "How long it took to acquire a write transaction for all tables.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableContention: (*metric.gaugeVec)(0x4001b2ab00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40012e7808)({
      MetricVec: (*prometheus.MetricVec)(0x4001c44ed0)({
       metricMap: (*prometheus.metricMap)(0x4001c44f00)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001997320)(Desc{fqName: "cilium_statedb_table_contention_seconds", help: "How long writers were blocked while waiting to acquire a write transaction for a specific table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=24) "table_contention_seconds",
       Help: (string) (len=96) "How long writers were blocked while waiting to acquire a write transaction for a specific table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableObjectCount: (*metric.gaugeVec)(0x4001b2ab80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40012e7810)({
      MetricVec: (*prometheus.MetricVec)(0x4001c44f60)({
       metricMap: (*prometheus.metricMap)(0x4001c44f90)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001997380)(Desc{fqName: "cilium_statedb_table_objects", help: "The amount of objects in a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=13) "table_objects",
       Help: (string) (len=39) "The amount of objects in a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableRevision: (*metric.gaugeVec)(0x4001b2ac00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40012e7818)({
      MetricVec: (*prometheus.MetricVec)(0x4001c44ff0)({
       metricMap: (*prometheus.metricMap)(0x4001c45020)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019973e0)(Desc{fqName: "cilium_statedb_table_revision", help: "The current revision of a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=14) "table_revision",
       Help: (string) (len=38) "The current revision of a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableDeleteTrackerCount: (*metric.gaugeVec)(0x4001b2ac80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40012e7820)({
      MetricVec: (*prometheus.MetricVec)(0x4001c45080)({
       metricMap: (*prometheus.metricMap)(0x4001c450b0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001997440)(Desc{fqName: "cilium_statedb_table_delete_trackers", help: "The amount of delete trackers for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=21) "table_delete_trackers",
       Help: (string) (len=48) "The amount of delete trackers for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardObjectCount: (*metric.gaugeVec)(0x4001b2ad00)({
     GaugeVec: (*prometheus.GaugeVec)(0x40012e7828)({
      MetricVec: (*prometheus.MetricVec)(0x4001c45110)({
       metricMap: (*prometheus.metricMap)(0x4001c45140)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x40019974a0)(Desc{fqName: "cilium_statedb_table_graveyard_objects", help: "The amount of objects in the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=23) "table_graveyard_objects",
       Help: (string) (len=57) "The amount of objects in the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardLowWatermark: (*metric.gaugeVec)(0x4001b2ad80)({
     GaugeVec: (*prometheus.GaugeVec)(0x40012e7830)({
      MetricVec: (*prometheus.MetricVec)(0x4001c451a0)({
       metricMap: (*prometheus.metricMap)(0x4001c451d0)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001997500)(Desc{fqName: "cilium_statedb_table_graveyard_low_watermark", help: "The lowest revision of a given table that has been processed by the graveyard garbage collector.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x83bda0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=29) "table_graveyard_low_watermark",
       Help: (string) (len=96) "The lowest revision of a given table that has been processed by the graveyard garbage collector.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    }),
    TableGraveyardCleaningDuration: (*metric.histogramVec)(0x4001b2ae00)({
     ObserverVec: (*prometheus.HistogramVec)(0x40012e7838)({
      MetricVec: (*prometheus.MetricVec)(0x4001c45230)({
       metricMap: (*prometheus.metricMap)(0x4001c45260)({
        mtx: (sync.RWMutex) {
         w: (sync.Mutex) {
          state: (int32) 0,
          sema: (uint32) 0
         },
         writerSem: (uint32) 0,
         readerSem: (uint32) 0,
         readerCount: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         },
         readerWait: (atomic.Int32) {
          _: (atomic.noCopy) {
          },
          v: (int32) 0
         }
        },
        metrics: (map[uint64][]prometheus.metricWithLabelValues) {
        },
        desc: (*prometheus.Desc)(0x4001997560)(Desc{fqName: "cilium_statedb_table_graveyard_cleaning_duration_seconds", help: "The time it took to clean the graveyard for a given table.", constLabels: {}, variableLabels: {table}}),
        newMetric: (func(...string) prometheus.Metric) 0x843db0
       }),
       curry: ([]prometheus.curriedLabelValue) <nil>,
       hashAdd: (func(uint64, string) uint64) 0x83b6d0,
       hashAddByte: (func(uint64, uint8) uint64) 0x83b700
      })
     }),
     metric: (metric.metric) {
      enabled: (bool) false,
      opts: (metric.Opts) {
       Namespace: (string) (len=6) "cilium",
       Subsystem: (string) (len=7) "statedb",
       Name: (string) (len=41) "table_graveyard_cleaning_duration_seconds",
       Help: (string) (len=58) "The time it took to clean the graveyard for a given table.",
       ConstLabels: (prometheus.Labels) <nil>,
       ConfigName: (string) "",
       Disabled: (bool) true
      },
      labels: (*metric.labelSet)(<nil>)
     }
    })
   }
  },
  defaultHandle: (statedb.Handle) {
   db: (*statedb.DB)(0x4001920d20)(<already shown>),
   name: (string) (len=2) "DB"
  }
 }),
 nodeAddrs: (*statedb.genTable[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress])(0x4001fda1c0)({
  pos: (int) 3,
  table: (string) (len=14) "node-addresses",
  smu: (*internal.sortableMutex)(0x4001fbe7c8)({
   Mutex: (sync.Mutex) {
    state: (int32) 0,
    sema: (uint32) 0
   },
   seq: (uint64) 7,
   acquireDuration: (time.Duration) 312ns
  }),
  primaryIndexer: (statedb.Index[github.com/cilium/cilium/pkg/datapath/tables.NodeAddress,github.com/cilium/cilium/pkg/datapath/tables.NodeAddressKey]) {
   Name: (string) (len=2) "id",
   FromObject: (func(tables.NodeAddress) index.KeySet) 0x1ccdd30,
   FromKey: (func(tables.NodeAddressKey) index.Key) 0x1cd0b70,
   Unique: (bool) true
  },
  primaryAnyIndexer: (statedb.anyIndexer) {
   name: (string) (len=2) "id",
   fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
   unique: (bool) true,
   pos: (int) 0
  },
  secondaryAnyIndexers: (map[string]statedb.anyIndexer) (len=2) {
   (string) (len=4) "name": (statedb.anyIndexer) {
    name: (string) (len=4) "name",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 4
   },
   (string) (len=9) "node-port": (statedb.anyIndexer) {
    name: (string) (len=9) "node-port",
    fromObject: (func(statedb.object) index.KeySet) 0x1cd6650,
    unique: (bool) false,
    pos: (int) 5
   }
  },
  indexPositions: (map[string]int) (len=6) {
   (string) (len=22) "__graveyard_revision__": (int) 3,
   (string) (len=4) "name": (int) 4,
   (string) (len=9) "node-port": (int) 5,
   (string) (len=2) "id": (int) 0,
   (string) (len=12) "__revision__": (int) 1,
   (string) (len=13) "__graveyard__": (int) 2
  }
 })
})

```


#### kvstore-locks

```
(map[string]kvstore.lockOwner) {
}

```


#### ongoing-endpoint-creations


#### Kernel version

```
Error: unable to get kernel version from "6.1.112-122.189.amzn2023.aarch64\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

```


#### Service list

```
ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.248.73:443 (active)     
                                          2 => 172.31.133.231:443 (active)    
2    10.100.203.172:443    ClusterIP      1 => 172.31.222.147:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.53.0.89:53 (active)         
                                          2 => 10.53.0.242:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.53.0.89:9153 (active)       
                                          2 => 10.53.0.242:9153 (active)      
5    10.100.128.104:2379   ClusterIP      1 => 10.53.0.195:2379 (active)      
```

#### Cilium memory map


```
00010000-02adc000 r-xp 00000000 103:01 37769126                          /usr/bin/cilium-agent
02ae0000-060b4000 r--p 02ad0000 103:01 37769126                          /usr/bin/cilium-agent
060c0000-0625d000 rw-p 060b0000 103:01 37769126                          /usr/bin/cilium-agent
0625d000-06a24000 rw-p 00000000 00:00 0 
4000000000-400c800000 rw-p 00000000 00:00 0 
400c800000-4010000000 ---p 00000000 00:00 0 
ffff65255000-ffff6547b000 rw-p 00000000 00:00 0 
ffff65483000-ffff655a4000 rw-p 00000000 00:00 0 
ffff655a4000-ffff655e5000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff655e5000-ffff65626000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff65626000-ffff65628000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff65628000-ffff6562a000 rw-s 00000000 00:0d 1043                       anon_inode:[perf_event]
ffff6562a000-ffff65bd1000 rw-p 00000000 00:00 0 
ffff65bd1000-ffff65cd1000 rw-p 00000000 00:00 0 
ffff65cd1000-ffff65ce2000 rw-p 00000000 00:00 0 
ffff65ce2000-ffff67ce2000 rw-p 00000000 00:00 0 
ffff67ce2000-ffff67d62000 ---p 00000000 00:00 0 
ffff67d62000-ffff67d63000 rw-p 00000000 00:00 0 
ffff67d63000-ffff87d62000 ---p 00000000 00:00 0 
ffff87d62000-ffff87d63000 rw-p 00000000 00:00 0 
ffff87d63000-ffffa7cf2000 ---p 00000000 00:00 0 
ffffa7cf2000-ffffa7cf3000 rw-p 00000000 00:00 0 
ffffa7cf3000-ffffabce4000 ---p 00000000 00:00 0 
ffffabce4000-ffffabce5000 rw-p 00000000 00:00 0 
ffffabce5000-ffffac4e2000 ---p 00000000 00:00 0 
ffffac4e2000-ffffac4e3000 rw-p 00000000 00:00 0 
ffffac4e3000-ffffac5e2000 ---p 00000000 00:00 0 
ffffac5e2000-ffffac642000 rw-p 00000000 00:00 0 
ffffac642000-ffffac644000 r--p 00000000 00:00 0                          [vvar]
ffffac644000-ffffac645000 r-xp 00000000 00:00 0                          [vdso]
ffffc24f0000-ffffc2511000 rw-p 00000000 00:00 0                          [stack]

```


#### Cilium encryption


