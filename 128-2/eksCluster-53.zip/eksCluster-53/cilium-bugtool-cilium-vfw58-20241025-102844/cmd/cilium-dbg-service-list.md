ID   Frontend              Service Type   Backend                             
1    10.100.0.1:443        ClusterIP      1 => 172.31.248.73:443 (active)     
                                          2 => 172.31.133.231:443 (active)    
2    10.100.203.172:443    ClusterIP      1 => 172.31.222.147:4244 (active)   
3    10.100.0.10:53        ClusterIP      1 => 10.53.0.89:53 (active)         
                                          2 => 10.53.0.242:53 (active)        
4    10.100.0.10:9153      ClusterIP      1 => 10.53.0.89:9153 (active)       
                                          2 => 10.53.0.242:9153 (active)      
5    10.100.128.104:2379   ClusterIP      1 => 10.53.0.195:2379 (active)      
