xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 537
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 529
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 527
cilium_host(4) clsact/egress cil_from_host-cilium_host id 523
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 473
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 470
lxc_health(7) clsact/ingress cil_from_container-lxc_health id 519
lxcc567fa974ade(9) clsact/ingress cil_from_container-lxcc567fa974ade id 532
lxcc5473fc01db8(11) clsact/ingress cil_from_container-lxcc5473fc01db8 id 556
lxc746a1f859e3f(15) clsact/ingress cil_from_container-lxc746a1f859e3f id 621

flow_dissector:

netfilter:

