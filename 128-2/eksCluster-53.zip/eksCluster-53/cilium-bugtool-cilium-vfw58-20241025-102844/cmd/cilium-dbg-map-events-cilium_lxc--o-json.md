{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.181:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:24.195Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.222.147:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:24.195Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:26.669Z",
  "value": "id=496   sec_id=3582731 flags=0x0000 ifindex=9   mac=4E:01:38:32:E4:8C nodemac=2A:A2:7F:2C:4C:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:29.990Z",
  "value": "id=1488  sec_id=3582731 flags=0x0000 ifindex=11  mac=1A:AD:1A:BD:23:27 nodemac=2E:CB:04:4E:94:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:29.991Z",
  "value": "id=978   sec_id=4     flags=0x0000 ifindex=7   mac=72:AF:51:D7:2A:26 nodemac=02:94:38:AC:33:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:30.067Z",
  "value": "id=496   sec_id=3582731 flags=0x0000 ifindex=9   mac=4E:01:38:32:E4:8C nodemac=2A:A2:7F:2C:4C:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:30.091Z",
  "value": "id=1488  sec_id=3582731 flags=0x0000 ifindex=11  mac=1A:AD:1A:BD:23:27 nodemac=2E:CB:04:4E:94:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:08.592Z",
  "value": "id=496   sec_id=3582731 flags=0x0000 ifindex=9   mac=4E:01:38:32:E4:8C nodemac=2A:A2:7F:2C:4C:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:08.593Z",
  "value": "id=1488  sec_id=3582731 flags=0x0000 ifindex=11  mac=1A:AD:1A:BD:23:27 nodemac=2E:CB:04:4E:94:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:08.593Z",
  "value": "id=978   sec_id=4     flags=0x0000 ifindex=7   mac=72:AF:51:D7:2A:26 nodemac=02:94:38:AC:33:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:08.623Z",
  "value": "id=1612  sec_id=3604221 flags=0x0000 ifindex=13  mac=06:F0:8B:D3:EC:54 nodemac=2E:70:B2:28:99:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:09.592Z",
  "value": "id=1488  sec_id=3582731 flags=0x0000 ifindex=11  mac=1A:AD:1A:BD:23:27 nodemac=2E:CB:04:4E:94:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:09.592Z",
  "value": "id=978   sec_id=4     flags=0x0000 ifindex=7   mac=72:AF:51:D7:2A:26 nodemac=02:94:38:AC:33:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:09.593Z",
  "value": "id=1612  sec_id=3604221 flags=0x0000 ifindex=13  mac=06:F0:8B:D3:EC:54 nodemac=2E:70:B2:28:99:08"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:09.593Z",
  "value": "id=496   sec_id=3582731 flags=0x0000 ifindex=9   mac=4E:01:38:32:E4:8C nodemac=2A:A2:7F:2C:4C:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:15.714Z",
  "value": "id=1077  sec_id=3604221 flags=0x0000 ifindex=15  mac=0E:AE:E0:A2:5F:8B nodemac=C2:9C:D1:31:52:76"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.53.0.221:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:22:27.195Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:35.442Z",
  "value": "id=978   sec_id=4     flags=0x0000 ifindex=7   mac=72:AF:51:D7:2A:26 nodemac=02:94:38:AC:33:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:35.442Z",
  "value": "id=496   sec_id=3582731 flags=0x0000 ifindex=9   mac=4E:01:38:32:E4:8C nodemac=2A:A2:7F:2C:4C:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:35.443Z",
  "value": "id=1077  sec_id=3604221 flags=0x0000 ifindex=15  mac=0E:AE:E0:A2:5F:8B nodemac=C2:9C:D1:31:52:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:35.443Z",
  "value": "id=1488  sec_id=3582731 flags=0x0000 ifindex=11  mac=1A:AD:1A:BD:23:27 nodemac=2E:CB:04:4E:94:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:36.433Z",
  "value": "id=1488  sec_id=3582731 flags=0x0000 ifindex=11  mac=1A:AD:1A:BD:23:27 nodemac=2E:CB:04:4E:94:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:36.433Z",
  "value": "id=978   sec_id=4     flags=0x0000 ifindex=7   mac=72:AF:51:D7:2A:26 nodemac=02:94:38:AC:33:F3"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:36.433Z",
  "value": "id=496   sec_id=3582731 flags=0x0000 ifindex=9   mac=4E:01:38:32:E4:8C nodemac=2A:A2:7F:2C:4C:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:36.433Z",
  "value": "id=1077  sec_id=3604221 flags=0x0000 ifindex=15  mac=0E:AE:E0:A2:5F:8B nodemac=C2:9C:D1:31:52:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.89:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:37.433Z",
  "value": "id=496   sec_id=3582731 flags=0x0000 ifindex=9   mac=4E:01:38:32:E4:8C nodemac=2A:A2:7F:2C:4C:39"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.195:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:37.433Z",
  "value": "id=1077  sec_id=3604221 flags=0x0000 ifindex=15  mac=0E:AE:E0:A2:5F:8B nodemac=C2:9C:D1:31:52:76"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.242:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:37.433Z",
  "value": "id=1488  sec_id=3582731 flags=0x0000 ifindex=11  mac=1A:AD:1A:BD:23:27 nodemac=2E:CB:04:4E:94:85"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.53.0.68:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:37.433Z",
  "value": "id=978   sec_id=4     flags=0x0000 ifindex=7   mac=72:AF:51:D7:2A:26 nodemac=02:94:38:AC:33:F3"
}

