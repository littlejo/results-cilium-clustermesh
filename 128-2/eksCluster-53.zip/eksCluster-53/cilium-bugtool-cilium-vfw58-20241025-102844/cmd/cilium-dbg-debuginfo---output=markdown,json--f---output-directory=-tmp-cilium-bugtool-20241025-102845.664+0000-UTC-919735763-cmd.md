markdown output at /tmp/cilium-bugtool-20241025-102845.664+0000-UTC-919735763/cmd/cilium-debuginfo-20241025-102846.403+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102845.664+0000-UTC-919735763/cmd/cilium-debuginfo-20241025-102846.403+0000-UTC.json
