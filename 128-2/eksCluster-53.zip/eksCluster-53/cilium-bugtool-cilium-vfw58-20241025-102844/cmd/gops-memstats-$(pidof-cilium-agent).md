alloc: 113.39MB (118897720 bytes)
total-alloc: 1.28GB (1372101120 bytes)
sys: 202.32MB (212146500 bytes)
lookups: 0
mallocs: 46989515
frees: 45788841
heap-alloc: 113.39MB (118897720 bytes)
heap-sys: 157.20MB (164831232 bytes)
heap-idle: 27.97MB (29327360 bytes)
heap-in-use: 129.23MB (135503872 bytes)
heap-released: 2.16MB (2260992 bytes)
heap-objects: 1200674
stack-in-use: 34.78MB (36470784 bytes)
stack-sys: 34.78MB (36470784 bytes)
stack-mspan-inuse: 2.13MB (2231520 bytes)
stack-mspan-sys: 2.40MB (2513280 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 1013.95KB (1038281 bytes)
gc-sys: 5.06MB (5301344 bytes)
next-gc: when heap-alloc >= 142.92MB (149858120 bytes)
last-gc: 2024-10-25 10:27:55.185828912 +0000 UTC
gc-pause-total: 11.54164ms
gc-pause: 97608
gc-pause-end: 1729852075185828912
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.00032720379330295905
enable-gc: true
debug-gc: false
