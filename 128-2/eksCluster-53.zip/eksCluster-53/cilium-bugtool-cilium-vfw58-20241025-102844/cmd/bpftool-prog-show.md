29: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:30+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
30: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:30+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
31: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:30+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
32: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:30+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
33: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:30+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
34: cgroup_device  name sd_devices  tag 632bd0628e770518  gpl
	loaded_at 2024-10-25T10:13:30+0000  uid 0
	xlated 464B  jited 456B  memlock 4096B
35: cgroup_device  name sd_devices  tag e03fc47ffe211ede  gpl
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 616B  jited 576B  memlock 4096B
36: cgroup_device  name sd_devices  tag 54c1abe6e18fc39c  gpl
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 696B  jited 632B  memlock 4096B
37: cgroup_skb  name sd_fw_egress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
38: cgroup_skb  name sd_fw_ingress  tag 6deef7357e7b4530  gpl
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
39: cgroup_device  name sd_devices  tag ee0e253c78993a24  gpl
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 416B  jited 424B  memlock 4096B
40: cgroup_device  name sd_devices  tag 47dd357395126b0c  gpl
	loaded_at 2024-10-25T10:13:31+0000  uid 0
	xlated 504B  jited 488B  memlock 4096B
45: cgroup_device  name sd_devices  tag 2f70d381e740929b  gpl
	loaded_at 2024-10-25T10:13:35+0000  uid 0
	xlated 560B  jited 528B  memlock 4096B
47: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:42+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
51: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:42+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
60: cgroup_device  tag 3918c82a5f4c0360
	loaded_at 2024-10-25T10:13:47+0000  uid 0
	xlated 64B  jited 128B  memlock 4096B
65: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
68: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
69: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
72: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:54+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
76: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
79: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:13:57+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
80: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
83: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:01+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
84: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
87: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:04+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
111: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:16+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
114: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:16+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
466: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
469: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:26+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
470: sched_cls  name cil_to_overlay  tag 9b0320726de189a0  gpl
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 352B  jited 288B  memlock 4096B
	btf_id 126
471: sched_cls  name __send_drop_notify  tag ef30c642bab96a8a  gpl
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 127
472: sched_cls  name tail_handle_ipv4  tag 634c38acdce4b3bd  gpl
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 1992B  jited 1600B  memlock 4096B  map_ids 71,70,77,72,97
	btf_id 128
473: sched_cls  name cil_from_overlay  tag f5c034120e9f01ca  gpl
	loaded_at 2024-10-25T10:14:27+0000  uid 0
	xlated 1072B  jited 936B  memlock 4096B  map_ids 72,97
	btf_id 129
474: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:28+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
477: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:28+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
500: sched_cls  name tail_handle_ipv4_cont  tag 1d1c506cf923bd53  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 9672B  jited 6280B  memlock 12288B  map_ids 71,109,37,106,78,79,35,72,70,73,110,36,33,34,77
	btf_id 158
501: sched_cls  name __send_drop_notify  tag 74dec143b7ed8d55  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 159
503: sched_cls  name tail_ipv4_to_endpoint  tag 8ff6b125683b3ee7  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 8744B  jited 5736B  memlock 12288B  map_ids 71,72,109,37,78,79,76,106,35,110,36,33,34
	btf_id 161
504: sched_cls  name tail_ipv4_ct_ingress  tag 204ed3dd98d897e8  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 6168B  jited 4712B  memlock 8192B  map_ids 72,110,78,79,109,80
	btf_id 163
507: sched_cls  name tail_handle_ipv4  tag f11390866085eafc  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,110
	btf_id 164
511: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,110
	btf_id 167
514: sched_cls  name handle_policy  tag 2fb9a0340a2d3c96  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 14680B  jited 10040B  memlock 16384B  map_ids 72,110,78,79,109,37,76,106,35,80,71,36,33,34
	btf_id 171
517: sched_cls  name tail_ipv4_ct_egress  tag 17256f43e4ba2bba  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 6128B  jited 4712B  memlock 8192B  map_ids 72,110,78,79,109,80
	btf_id 175
519: sched_cls  name cil_from_container  tag 5d006c898612fcdb  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 728B  jited 752B  memlock 4096B  map_ids 110,72
	btf_id 177
520: sched_cls  name tail_handle_arp  tag 40ce60508982a2bc  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,110
	btf_id 178
521: sched_cls  name __send_drop_notify  tag 0c156b0012711a56  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 180
523: sched_cls  name cil_from_host  tag 4c8cc79ae4cae1c7  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 2256B  jited 1728B  memlock 4096B  map_ids 72,71,111
	btf_id 182
524: sched_cls  name tail_handle_ipv4_from_host  tag c9835688aedf78d9  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,111
	btf_id 183
525: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,111
	btf_id 184
527: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 72
	btf_id 186
529: sched_cls  name cil_to_host  tag dcc4c1201ae3c17d  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 408B  jited 376B  memlock 4096B  map_ids 72
	btf_id 189
530: sched_cls  name __send_drop_notify  tag 0c156b0012711a56  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 190
532: sched_cls  name cil_from_container  tag f580544a15135b6e  gpl
	loaded_at 2024-10-25T10:14:29+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 115,72
	btf_id 193
534: sched_cls  name handle_policy  tag 81234cebd6d8a162  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,115,78,79,116,37,76,87,35,80,71,36,33,34
	btf_id 196
535: sched_cls  name tail_handle_ipv4_from_host  tag c9835688aedf78d9  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,113
	btf_id 195
536: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,113
	btf_id 198
537: sched_cls  name cil_from_netdev  tag 612ae21d69e3648a  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 2032B  jited 1824B  memlock 4096B  map_ids 72,118,71
	btf_id 200
538: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,115
	btf_id 197
540: sched_cls  name tail_handle_ipv4  tag 8b8d31d7507f3358  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,115
	btf_id 202
541: sched_cls  name tail_handle_ipv4_from_host  tag c9835688aedf78d9  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 4208B  jited 3080B  memlock 8192B  map_ids 70,71,72,73,37,77,118
	btf_id 203
542: sched_cls  name tail_handle_ipv4_from_netdev  tag 43aa412a10dbf267  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 864B  jited 800B  memlock 4096B  map_ids 72,118
	btf_id 205
545: sched_cls  name __send_drop_notify  tag 0c156b0012711a56  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 368B  jited 312B  memlock 4096B  map_ids 37
	btf_id 208
546: sched_cls  name tail_ipv4_to_endpoint  tag 6ec8afae2eabe972  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,116,37,78,79,76,87,35,115,36,33,34
	btf_id 204
547: sched_cls  name tail_ipv4_ct_ingress  tag cbd0ffae3345e6c9  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,115,78,79,116,80
	btf_id 209
548: sched_cls  name __send_drop_notify  tag 5a02406e7e602b8f  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 212
549: sched_cls  name tail_handle_ipv4_cont  tag 090635b744117e43  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,116,37,87,78,79,35,72,70,73,115,36,33,34,77
	btf_id 213
550: sched_cls  name tail_handle_arp  tag f29017642203b8a0  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,115
	btf_id 214
551: sched_cls  name tail_ipv4_ct_egress  tag 8586d1efe4dd98c6  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,115,78,79,116,80
	btf_id 215
553: sched_cls  name handle_policy  tag 23d80c0f39e2004c  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,119,78,79,120,37,76,98,35,80,71,36,33,34
	btf_id 211
554: sched_cls  name tail_ipv4_ct_ingress  tag 330e07a41ad257e8  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,119,78,79,120,80
	btf_id 217
556: sched_cls  name cil_from_container  tag 92eacc4a13b34d37  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 119,72
	btf_id 219
557: sched_cls  name tail_handle_ipv4  tag 8d393193e6ef5fc6  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,119
	btf_id 220
558: sched_cls  name tail_ipv4_ct_egress  tag 8586d1efe4dd98c6  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,119,78,79,120,80
	btf_id 221
559: sched_cls  name tail_ipv4_to_endpoint  tag 63b6729a25201050  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,120,37,78,79,76,98,35,119,36,33,34
	btf_id 222
560: sched_cls  name tail_handle_arp  tag 169a933b11991475  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,119
	btf_id 223
561: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
564: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
565: sched_cls  name tail_handle_ipv4_cont  tag e44e6eeb11ffdc61  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,120,37,98,78,79,35,72,70,73,119,36,33,34,77
	btf_id 224
566: sched_cls  name __send_drop_notify  tag b83aee80db3ae089  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 225
567: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,119
	btf_id 226
568: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
571: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:14:30+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
611: sched_cls  name tail_ipv4_to_endpoint  tag a4d2503e3239a251  gpl
	loaded_at 2024-10-25T10:22:15+0000  uid 0
	xlated 8744B  jited 5760B  memlock 12288B  map_ids 71,72,135,37,78,79,76,133,35,134,36,33,34
	btf_id 241
612: sched_cls  name handle_policy  tag 627e04deda2b61c5  gpl
	loaded_at 2024-10-25T10:22:15+0000  uid 0
	xlated 14680B  jited 10088B  memlock 16384B  map_ids 72,134,78,79,135,37,76,133,35,80,71,36,33,34
	btf_id 242
613: sched_cls  name __send_drop_notify  tag af158ea2b7a31a8a  gpl
	loaded_at 2024-10-25T10:22:15+0000  uid 0
	xlated 376B  jited 312B  memlock 4096B  map_ids 37
	btf_id 243
614: sched_cls  name tail_ipv4_ct_ingress  tag 298db7977fc947f2  gpl
	loaded_at 2024-10-25T10:22:15+0000  uid 0
	xlated 6168B  jited 4728B  memlock 8192B  map_ids 72,134,78,79,135,80
	btf_id 244
615: sched_cls  name tail_ipv4_ct_egress  tag d234d4ad1f40c949  gpl
	loaded_at 2024-10-25T10:22:15+0000  uid 0
	xlated 6128B  jited 4728B  memlock 8192B  map_ids 72,134,78,79,135,80
	btf_id 245
616: sched_cls  name tail_handle_arp  tag f085cbd5d54b4052  gpl
	loaded_at 2024-10-25T10:22:15+0000  uid 0
	xlated 1432B  jited 1128B  memlock 4096B  map_ids 72,134
	btf_id 246
617: sched_cls  name tail_no_service_ipv4  tag f47e953ae5b5d1fd  gpl
	loaded_at 2024-10-25T10:22:15+0000  uid 0
	xlated 4624B  jited 3152B  memlock 8192B  map_ids 72,134
	btf_id 247
618: sched_cls  name tail_handle_ipv4_cont  tag 5131a3a24dbb59b9  gpl
	loaded_at 2024-10-25T10:22:15+0000  uid 0
	xlated 9672B  jited 6320B  memlock 12288B  map_ids 71,135,37,133,78,79,35,72,70,73,134,36,33,34,77
	btf_id 248
620: sched_cls  name tail_handle_ipv4  tag b4fae3b5917f338f  gpl
	loaded_at 2024-10-25T10:22:15+0000  uid 0
	xlated 5952B  jited 4408B  memlock 8192B  map_ids 80,72,74,78,79,75,35,134
	btf_id 250
621: sched_cls  name cil_from_container  tag 931fa6898a1a7f7e  gpl
	loaded_at 2024-10-25T10:22:15+0000  uid 0
	xlated 728B  jited 760B  memlock 4096B  map_ids 134,72
	btf_id 251
622: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:15+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
625: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:15+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
638: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
641: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
642: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
645: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
646: cgroup_device  name sd_devices  tag 3b0b81b071f088cd  gpl
	loaded_at 2024-10-25T10:22:18+0000  uid 0
	xlated 440B  jited 432B  memlock 4096B
649: cgroup_device  tag 531db05b114e9af3
	loaded_at 2024-10-25T10:22:18+0000  uid 0
	xlated 512B  jited 472B  memlock 4096B
