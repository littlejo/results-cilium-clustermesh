Total: 537
TCP:   1066 (estab 291, closed 756, orphaned 0, timewait 293)

Transport Total     IP        IPv6
RAW	  3         2         1        
UDP	  7         4         3        
TCP	  310       303       7        
INET	  320       309       11       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q                   Local Address:Port  Peer Address:PortProcess                                                                         
UNCONN 0      0                  172.31.222.147%ens5:68         0.0.0.0:*    uid:192 ino:15565 sk:25c cgroup:unreachable:c4e <->                            
UNCONN 0      0                            127.0.0.1:43083      0.0.0.0:*    users:(("cilium-agent",pid=1,fd=42)) ino:22376 sk:25d fwmark:0xb00 cgroup:/ <->
UNCONN 0      0                              0.0.0.0:8472       0.0.0.0:*    ino:22411 sk:25e cgroup:/ <->                                                  
UNCONN 0      0                            127.0.0.1:323        0.0.0.0:*    ino:15347 sk:25f cgroup:unreachable:f0c <->                                    
UNCONN 0      0                                 [::]:8472          [::]:*    ino:22410 sk:260 cgroup:/ v6only:1 <->                                         
UNCONN 0      0                                [::1]:323           [::]:*    ino:15348 sk:261 cgroup:unreachable:f0c v6only:1 <->                           
UNCONN 0      0      [fe80::8d5:23ff:fef2:b575]%ens5:546           [::]:*    uid:192 ino:15557 sk:262 cgroup:unreachable:c4e v6only:1 <->                   
