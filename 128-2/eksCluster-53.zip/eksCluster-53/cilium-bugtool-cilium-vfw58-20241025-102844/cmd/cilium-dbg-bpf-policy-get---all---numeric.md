Endpoint ID: 496
Path: /sys/fs/bpf/tc/globals/cilium_policy_00496

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    65236   586       0        
Allow    Ingress     1          ANY          NONE         disabled    81162   935       0        
Allow    Egress      0          ANY          NONE         disabled    28364   280       0        


Endpoint ID: 978
Path: /sys/fs/bpf/tc/globals/cilium_policy_00978

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    392312   5002      0        
Allow    Ingress     1          ANY          NONE         disabled    11592    134       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1077
Path: /sys/fs/bpf/tc/globals/cilium_policy_01077

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3218084   31609     0        
Allow    Ingress     1          ANY          NONE         disabled    2576417   25483     0        
Allow    Egress      0          ANY          NONE         disabled    3720625   35903     0        


Endpoint ID: 1488
Path: /sys/fs/bpf/tc/globals/cilium_policy_01488

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    68882   621       0        
Allow    Ingress     1          ANY          NONE         disabled    80999   930       0        
Allow    Egress      0          ANY          NONE         disabled    29201   288       0        


Endpoint ID: 2999
Path: /sys/fs/bpf/tc/globals/cilium_policy_02999

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


