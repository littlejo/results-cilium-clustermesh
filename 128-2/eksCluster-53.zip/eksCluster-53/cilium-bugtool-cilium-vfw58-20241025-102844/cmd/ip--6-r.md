fe80::/64 dev ens5 proto kernel metric 256 pref medium
fe80::/64 dev cilium_net proto kernel metric 256 pref medium
fe80::/64 dev cilium_host proto kernel metric 256 pref medium
fe80::/64 dev cilium_vxlan proto kernel metric 256 pref medium
fe80::/64 dev lxc_health proto kernel metric 256 pref medium
fe80::/64 dev lxcc567fa974ade proto kernel metric 256 pref medium
fe80::/64 dev lxcc5473fc01db8 proto kernel metric 256 pref medium
fe80::/64 dev lxc746a1f859e3f proto kernel metric 256 pref medium
