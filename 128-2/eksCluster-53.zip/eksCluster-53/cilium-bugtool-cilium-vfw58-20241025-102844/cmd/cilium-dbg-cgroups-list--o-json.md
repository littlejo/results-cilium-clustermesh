[
  {
    "containers": [
      {
        "cgroup-id": 8622,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddffb38e1_8cbb_40d2_9d46_1a09f3fe80ba.slice/cri-containerd-b1342b3dc12f38001024300d5c8d53381187626f908a151ad869e6e95a825fce.scope"
      },
      {
        "cgroup-id": 8790,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddffb38e1_8cbb_40d2_9d46_1a09f3fe80ba.slice/cri-containerd-ba607bb58f9aa228fde87b1648d96d60aa956de13afed4d8946e12d5073078d2.scope"
      },
      {
        "cgroup-id": 8706,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddffb38e1_8cbb_40d2_9d46_1a09f3fe80ba.slice/cri-containerd-7bad12029ea67d753e9132233b7315fc6fcbfe7bd0997a4398efb5c388543324.scope"
      }
    ],
    "ips": [
      "10.53.0.195"
    ],
    "name": "clustermesh-apiserver-65c8447649-m6xtr",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7110,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc93a2a80_9a4a_40c1_a0b0_ea002f064f37.slice/cri-containerd-30a26a7d90e94bb3f55d8c8ea8aef987c0091f2a2055dbfdb65302332c1af514.scope"
      }
    ],
    "ips": [
      "10.53.0.89"
    ],
    "name": "coredns-cc6ccd49c-pn6vt",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7278,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0e2f4c09_3abd_40ea_b53e_084f6a6d79dc.slice/cri-containerd-e606afc806811f9d7710cfd0ef904ced90f108cbbbb5c90219cd1d786bfdd197.scope"
      }
    ],
    "ips": [
      "10.53.0.242"
    ],
    "name": "coredns-cc6ccd49c-m7f65",
    "namespace": "kube-system"
  }
]

