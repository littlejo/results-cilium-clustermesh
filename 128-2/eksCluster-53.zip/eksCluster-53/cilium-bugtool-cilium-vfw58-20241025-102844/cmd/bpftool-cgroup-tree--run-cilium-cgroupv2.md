CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    40       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    33       cgroup_inet_ingress multi           sd_fw_ingress                  
    32       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    35       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    45       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    31       cgroup_inet_ingress multi           sd_fw_ingress                  
    30       cgroup_inet_egress multi           sd_fw_egress                   
    29       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    34       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    38       cgroup_inet_ingress multi           sd_fw_ingress                  
    37       cgroup_inet_egress multi           sd_fw_egress                   
    36       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod767ac42c_a644_453c_b35a_0c2898467557.slice/cri-containerd-32cafbc36b5a55416f456a36d8455331abd56fa77ec73a9013d62c27f77870d6.scope
    68       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod767ac42c_a644_453c_b35a_0c2898467557.slice/cri-containerd-fba58d516b81b91a818366058998bfe869c659cca9e62b4488a736ba0c5f3811.scope
    114      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod272a588d_2609_44a7_91a1_405af77f7e46.slice/cri-containerd-1df2ebe04fa7f8159b981561be4d42763e8eef7bdda6b37a3ff9ebcb0254f5e7.scope
    51       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod272a588d_2609_44a7_91a1_405af77f7e46.slice/cri-containerd-fd7175f4789b96c065ade3935b31a9ba2d2af7dbe24d6ae54948415b1b7c5ca8.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc93a2a80_9a4a_40c1_a0b0_ea002f064f37.slice/cri-containerd-b1c91b26e9ecce2e18118ac930eacd0d826be89d268b7abf0f3407db35831190.scope
    469      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podc93a2a80_9a4a_40c1_a0b0_ea002f064f37.slice/cri-containerd-30a26a7d90e94bb3f55d8c8ea8aef987c0091f2a2055dbfdb65302332c1af514.scope
    477      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0e2f4c09_3abd_40ea_b53e_084f6a6d79dc.slice/cri-containerd-e606afc806811f9d7710cfd0ef904ced90f108cbbbb5c90219cd1d786bfdd197.scope
    571      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod0e2f4c09_3abd_40ea_b53e_084f6a6d79dc.slice/cri-containerd-fe31e90305cb30342daa99ca3923e6c21b3cdba5312e72e7d1849db406865d34.scope
    564      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda34e1c0b_0255_4cee_b5a2_7c824de46391.slice/cri-containerd-849717bf31abbbdaa60de085f08908bee1a7ab92d064e84a9697ff4b0ece0209.scope
    83       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda34e1c0b_0255_4cee_b5a2_7c824de46391.slice/cri-containerd-f1cd20b18109b33f2abd4004b2403b602c23c422ae3bb1a6e9e249695b379407.scope
    72       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddffb38e1_8cbb_40d2_9d46_1a09f3fe80ba.slice/cri-containerd-34709123e9c2c2fcc95e25b1eaae933ef204377374f16394eae41fbe6cb498b8.scope
    625      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddffb38e1_8cbb_40d2_9d46_1a09f3fe80ba.slice/cri-containerd-7bad12029ea67d753e9132233b7315fc6fcbfe7bd0997a4398efb5c388543324.scope
    645      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddffb38e1_8cbb_40d2_9d46_1a09f3fe80ba.slice/cri-containerd-b1342b3dc12f38001024300d5c8d53381187626f908a151ad869e6e95a825fce.scope
    641      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poddffb38e1_8cbb_40d2_9d46_1a09f3fe80ba.slice/cri-containerd-ba607bb58f9aa228fde87b1648d96d60aa956de13afed4d8946e12d5073078d2.scope
    649      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod28d9cb0e_8abf_469c_bffb_4515dd1adc46.slice/cri-containerd-a41397684ecbcf02367645781e91e90491e6455452883fc91687f5ecece3be3e.scope
    79       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod28d9cb0e_8abf_469c_bffb_4515dd1adc46.slice/cri-containerd-2e19e761bcf8afba10bace5895c3f86df12ccd4fefc6e5193753e1fc2ac508e6.scope
    87       cgroup_device   multi                                          
