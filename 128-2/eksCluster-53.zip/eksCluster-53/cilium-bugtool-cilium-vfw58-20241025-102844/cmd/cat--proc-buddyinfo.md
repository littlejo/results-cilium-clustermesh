Node 0, zone      DMA      0     13     10     13      4      2      2      4      3      3    175 
Node 0, zone   Normal    434     38     47      3     15      9      2      3      5      3      6 
