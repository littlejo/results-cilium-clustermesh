IP ADDRESS         LOCAL ENDPOINT INFO
10.53.0.242:0      id=1488  sec_id=3582731 flags=0x0000 ifindex=11  mac=1A:AD:1A:BD:23:27 nodemac=2E:CB:04:4E:94:85   
10.53.0.195:0      id=1077  sec_id=3604221 flags=0x0000 ifindex=15  mac=0E:AE:E0:A2:5F:8B nodemac=C2:9C:D1:31:52:76   
10.53.0.181:0      (localhost)                                                                                        
172.31.222.147:0   (localhost)                                                                                        
10.53.0.89:0       id=496   sec_id=3582731 flags=0x0000 ifindex=9   mac=4E:01:38:32:E4:8C nodemac=2A:A2:7F:2C:4C:39   
10.53.0.68:0       id=978   sec_id=4     flags=0x0000 ifindex=7   mac=72:AF:51:D7:2A:26 nodemac=02:94:38:AC:33:F3     
