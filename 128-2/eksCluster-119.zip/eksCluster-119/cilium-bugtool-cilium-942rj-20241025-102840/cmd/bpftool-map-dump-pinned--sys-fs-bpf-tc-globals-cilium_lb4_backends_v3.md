key: 06 00 00 00  value: ac 1f fa 37 10 94 00 00  00 00 00 00
key: 0d 00 00 00  value: 0a 77 00 ae 09 4b 00 00  00 00 00 00
key: 0a 00 00 00  value: 0a 77 00 0b 23 c1 00 00  00 00 00 00
key: 0b 00 00 00  value: 0a 77 00 0b 00 35 00 00  00 00 00 00
key: 08 00 00 00  value: 0a 77 00 23 23 c1 00 00  00 00 00 00
key: 09 00 00 00  value: 0a 77 00 23 00 35 00 00  00 00 00 00
key: 07 00 00 00  value: ac 1f 98 6f 01 bb 00 00  00 00 00 00
key: 01 00 00 00  value: ac 1f ee e5 01 bb 00 00  00 00 00 00
Found 8 elements
