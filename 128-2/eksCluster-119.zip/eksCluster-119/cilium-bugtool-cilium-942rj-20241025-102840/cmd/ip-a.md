1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host noprefixroute 
       valid_lft forever preferred_lft forever
2: ens5: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc mq state UP group default qlen 1000
    link/ether 0a:38:b8:90:85:c9 brd ff:ff:ff:ff:ff:ff
    altname enp0s5
    inet 172.31.250.55/18 metric 1024 brd 172.31.255.255 scope global dynamic ens5
       valid_lft 2701sec preferred_lft 2701sec
    inet6 fe80::838:b8ff:fe90:85c9/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 1a:15:f9:f5:40:2f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::1815:f9ff:fef5:402f/64 scope link 
       valid_lft forever preferred_lft forever
6: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:a8:84:d4:2f:f7 brd ff:ff:ff:ff:ff:ff
    inet 10.119.0.245/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::ca8:84ff:fed4:2ff7/64 scope link 
       valid_lft forever preferred_lft forever
7: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 86:d1:ce:83:c5:87 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::84d1:ceff:fe83:c587/64 scope link 
       valid_lft forever preferred_lft forever
9: lxc_health@if8: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether f6:af:35:4f:6a:2b brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::f4af:35ff:fe4f:6a2b/64 scope link 
       valid_lft forever preferred_lft forever
11: lxc0251d8d9a87a@if10: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:27:53:30:e5:cb brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::6827:53ff:fe30:e5cb/64 scope link 
       valid_lft forever preferred_lft forever
13: lxcbb21d8bd1b0b@if12: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:74:6d:a2:2c:cc brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::9c74:6dff:fea2:2ccc/64 scope link 
       valid_lft forever preferred_lft forever
17: lxca0e8bf937e34@if16: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 9001 qdisc noqueue state UP group default qlen 1000
    link/ether e2:ad:f9:34:94:be brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::e0ad:f9ff:fe34:94be/64 scope link 
       valid_lft forever preferred_lft forever
