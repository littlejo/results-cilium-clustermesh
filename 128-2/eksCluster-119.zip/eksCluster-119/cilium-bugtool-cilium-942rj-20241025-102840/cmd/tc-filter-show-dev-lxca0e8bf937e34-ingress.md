filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxca0e8bf937e34 direct-action not_in_hw id 607 tag ecfaac0cbe15d2c2 jited 
