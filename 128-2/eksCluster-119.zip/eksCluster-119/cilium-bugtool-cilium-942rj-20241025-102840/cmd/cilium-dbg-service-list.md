ID   Frontend            Service Type   Backend                            
1    10.100.0.1:443      ClusterIP      1 => 172.31.238.229:443 (active)   
                                        2 => 172.31.152.111:443 (active)   
2    10.100.5.12:443     ClusterIP      1 => 172.31.250.55:4244 (active)   
3    10.100.0.10:53      ClusterIP      1 => 10.119.0.35:53 (active)       
                                        2 => 10.119.0.11:53 (active)       
4    10.100.0.10:9153    ClusterIP      1 => 10.119.0.35:9153 (active)     
                                        2 => 10.119.0.11:9153 (active)     
5    10.100.3.131:2379   ClusterIP      1 => 10.119.0.174:2379 (active)    
