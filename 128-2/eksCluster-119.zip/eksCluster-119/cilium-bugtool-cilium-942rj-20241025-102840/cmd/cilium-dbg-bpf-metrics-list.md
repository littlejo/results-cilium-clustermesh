REASON                    DIRECTION   PACKETS   BYTES      LINE   FILE
Interface                 INGRESS     211701    83951743   1132   bpf_host.c
Interface                 INGRESS     9516      743367     677    bpf_overlay.c
Success                   EGRESS      4692      357201     1694   bpf_host.c
Success                   EGRESS      86750     11926130   1308   bpf_lxc.c
Success                   EGRESS      9360      731438     53     encap.h
Success                   INGRESS     103721    12364744   235    trace.h
Success                   INGRESS     98248     11934672   86     l3.h
Unsupported L3 protocol   EGRESS      48        3684       1492   bpf_lxc.c
