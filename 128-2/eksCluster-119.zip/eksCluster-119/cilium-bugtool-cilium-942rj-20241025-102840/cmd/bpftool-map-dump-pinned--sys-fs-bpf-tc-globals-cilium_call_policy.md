key: 18 00 00 00  value: 13 02 00 00
key: 3d 00 00 00  value: 1d 02 00 00
key: 18 03 00 00  value: 04 02 00 00
key: e7 05 00 00  value: 57 02 00 00
Found 4 elements
