alloc: 118.61MB (124372504 bytes)
total-alloc: 1.32GB (1414139176 bytes)
sys: 210.13MB (220341588 bytes)
lookups: 0
mallocs: 47490783
frees: 46305997
heap-alloc: 118.61MB (124372504 bytes)
heap-sys: 165.33MB (173359104 bytes)
heap-idle: 28.23MB (29597696 bytes)
heap-in-use: 137.10MB (143761408 bytes)
heap-released: 11.05MB (11591680 bytes)
heap-objects: 1184786
stack-in-use: 34.62MB (36306944 bytes)
stack-sys: 34.62MB (36306944 bytes)
stack-mspan-inuse: 2.16MB (2264480 bytes)
stack-mspan-sys: 2.35MB (2464320 bytes)
stack-mcache-inuse: 2.34KB (2400 bytes)
stack-mcache-sys: 15.23KB (15600 bytes)
other-sys: 808.40KB (827801 bytes)
gc-sys: 5.13MB (5384256 bytes)
next-gc: when heap-alloc >= 160.30MB (168084952 bytes)
last-gc: 2024-10-25 10:28:41.849705653 +0000 UTC
gc-pause-total: 5.100195ms
gc-pause: 90568
gc-pause-end: 1729852121849705653
num-gc: 72
num-forced-gc: 0
gc-cpu-fraction: 0.00030784875651314
enable-gc: true
debug-gc: false
