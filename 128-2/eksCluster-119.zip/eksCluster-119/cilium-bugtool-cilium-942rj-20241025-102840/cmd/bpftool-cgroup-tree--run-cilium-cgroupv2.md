CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    43       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    36       cgroup_inet_ingress multi           sd_fw_ingress                  
    35       cgroup_inet_egress multi           sd_fw_egress                   
/run/cilium/cgroupv2/system.slice/dbus-broker.service
    42       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-homed.service
    38       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/chronyd.service
    48       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    34       cgroup_inet_ingress multi           sd_fw_ingress                  
    33       cgroup_inet_egress multi           sd_fw_egress                   
    32       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    37       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    41       cgroup_inet_ingress multi           sd_fw_ingress                  
    40       cgroup_inet_egress multi           sd_fw_egress                   
    39       cgroup_device   multi           sd_devices                     
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1e57842b_e1fa_4a6f_bf11_01b25ca3fd72.slice/cri-containerd-4e1e6b917c9e244dbc848511f0ace3ad0125c33dd76efa57a9a06e16478a33a8.scope
    57       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1e57842b_e1fa_4a6f_bf11_01b25ca3fd72.slice/cri-containerd-2bf678297e6c5aaa01ce0641e90a06caab0307d9bbfa25883a3d51e4b1eb1885.scope
    60       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1fc028fe_2a34_45df_bdba_30a53364cd10.slice/cri-containerd-b56772b87dca39055bdb461321e875975dc445f46f916f13b403673ac02fcaac.scope
    535      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1fc028fe_2a34_45df_bdba_30a53364cd10.slice/cri-containerd-88b33eeba409e1aed7cd523fcdb21c1680804b9ef17811c5c8471de889fc89c3.scope
    539      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbecb1283_4265_4697_9c9d_f1a1d17f5aa8.slice/cri-containerd-c100662caf0a6a535b7eb2760663e2a6de54794cb559dc172c80c1aa9cd8b18b.scope
    90       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podbecb1283_4265_4697_9c9d_f1a1d17f5aa8.slice/cri-containerd-f1acb26d6e74102f5636c9c3d0db994b410843b46e77ce3cf46ac7952e58bc01.scope
    133      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda001b824_f5c4_4c5a_b5e3_f61931540c97.slice/cri-containerd-b1d63e16f40fd5611742b69970e3bb31d5beee28864aadd1058cabd872a7ce22.scope
    554      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda001b824_f5c4_4c5a_b5e3_f61931540c97.slice/cri-containerd-59736b67d22681d3069499ae83c11873d93d4306b96cb9a42666b88b737e37d6.scope
    558      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36cb1362_e638_47a8_aede_b2844f4d0afe.slice/cri-containerd-c44ccd325da5e92b5296b81d7a028ca5021c3d3f8a5fb090359ea1bd263b69eb.scope
    612      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36cb1362_e638_47a8_aede_b2844f4d0afe.slice/cri-containerd-37bcd63fa1d127a4cfcbfa111de071181ed32e66f67599d4e67d75b97832864a.scope
    628      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36cb1362_e638_47a8_aede_b2844f4d0afe.slice/cri-containerd-1c994bdf68015453ba4aeb089578a71f185c811a67d437746b4f4bcbbf0c107c.scope
    636      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36cb1362_e638_47a8_aede_b2844f4d0afe.slice/cri-containerd-28c6d7892513c234fa292fed322c9b256543af6da91b636ff38026743314f313.scope
    632      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9f738de2_d4f1_4d98_9bfa_9eb93fd9b112.slice/cri-containerd-248a102056dcc584aa97c99135e9d7baeb7908f9629c27738336e3cb676f5106.scope
    98       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod9f738de2_d4f1_4d98_9bfa_9eb93fd9b112.slice/cri-containerd-128225238a7777de2841d959b1fa22f10a6973e5705d28b86cb5623483279e3c.scope
    106      cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod42032922_e14a_445c_ae8d_9f62df705fce.slice/cri-containerd-9c78180682504929bd86de91f2c1f40257415c962c8791654635c5c57cdda4bb.scope
    94       cgroup_device   multi                                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod42032922_e14a_445c_ae8d_9f62df705fce.slice/cri-containerd-3c452f8e8bf39db4b3983a325a55fa1dbf6a7191eb1b3021e62705249888a000.scope
    102      cgroup_device   multi                                          
