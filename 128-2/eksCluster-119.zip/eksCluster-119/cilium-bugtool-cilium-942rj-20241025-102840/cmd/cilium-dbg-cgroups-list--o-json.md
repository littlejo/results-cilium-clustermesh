[
  {
    "containers": [
      {
        "cgroup-id": 7535,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod1fc028fe_2a34_45df_bdba_30a53364cd10.slice/cri-containerd-88b33eeba409e1aed7cd523fcdb21c1680804b9ef17811c5c8471de889fc89c3.scope"
      }
    ],
    "ips": [
      "10.119.0.35"
    ],
    "name": "coredns-cc6ccd49c-xgqsk",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 9215,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36cb1362_e638_47a8_aede_b2844f4d0afe.slice/cri-containerd-28c6d7892513c234fa292fed322c9b256543af6da91b636ff38026743314f313.scope"
      },
      {
        "cgroup-id": 9131,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36cb1362_e638_47a8_aede_b2844f4d0afe.slice/cri-containerd-37bcd63fa1d127a4cfcbfa111de071181ed32e66f67599d4e67d75b97832864a.scope"
      },
      {
        "cgroup-id": 9299,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod36cb1362_e638_47a8_aede_b2844f4d0afe.slice/cri-containerd-1c994bdf68015453ba4aeb089578a71f185c811a67d437746b4f4bcbbf0c107c.scope"
      }
    ],
    "ips": [
      "10.119.0.174"
    ],
    "name": "clustermesh-apiserver-5dfb8d7b84-xhtcx",
    "namespace": "kube-system"
  },
  {
    "containers": [
      {
        "cgroup-id": 7787,
        "cgroup-path": "/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda001b824_f5c4_4c5a_b5e3_f61931540c97.slice/cri-containerd-59736b67d22681d3069499ae83c11873d93d4306b96cb9a42666b88b737e37d6.scope"
      }
    ],
    "ips": [
      "10.119.0.11"
    ],
    "name": "coredns-cc6ccd49c-dhpbw",
    "namespace": "kube-system"
  }
]

