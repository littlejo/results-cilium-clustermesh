xdp:

tc:
ens5(2) clsact/ingress cil_from_netdev-ens5 id 492
cilium_net(5) clsact/ingress cil_to_host-cilium_net id 489
cilium_host(6) clsact/ingress cil_to_host-cilium_host id 484
cilium_host(6) clsact/egress cil_from_host-cilium_host id 482
cilium_vxlan(7) clsact/ingress cil_from_overlay-cilium_vxlan id 476
cilium_vxlan(7) clsact/egress cil_to_overlay-cilium_vxlan id 477
lxc_health(9) clsact/ingress cil_from_container-lxc_health id 513
lxc0251d8d9a87a(11) clsact/ingress cil_from_container-lxc0251d8d9a87a id 530
lxcbb21d8bd1b0b(13) clsact/ingress cil_from_container-lxcbb21d8bd1b0b id 543
lxca0e8bf937e34(17) clsact/ingress cil_from_container-lxca0e8bf937e34 id 607

flow_dissector:

netfilter:

