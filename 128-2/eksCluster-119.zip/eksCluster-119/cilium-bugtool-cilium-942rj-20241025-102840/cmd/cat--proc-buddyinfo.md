Node 0, zone      DMA      2     43     21     35      9      5      3      2      2      4    172 
Node 0, zone   Normal      4      1      2      2      2      2      4      1      0      2      9 
