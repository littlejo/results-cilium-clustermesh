IP ADDRESS        LOCAL ENDPOINT INFO
10.119.0.174:0    id=1511  sec_id=7891667 flags=0x0000 ifindex=17  mac=D6:34:58:85:AD:61 nodemac=E2:AD:F9:34:94:BE   
10.119.0.129:0    id=792   sec_id=4     flags=0x0000 ifindex=9   mac=AA:5A:43:1B:76:66 nodemac=F6:AF:35:4F:6A:2B     
172.31.250.55:0   (localhost)                                                                                        
10.119.0.245:0    (localhost)                                                                                        
10.119.0.11:0     id=61    sec_id=7887282 flags=0x0000 ifindex=13  mac=CA:29:1D:ED:FF:A0 nodemac=9E:74:6D:A2:2C:CC   
10.119.0.35:0     id=24    sec_id=7887282 flags=0x0000 ifindex=11  mac=E2:1F:47:0C:F0:76 nodemac=6A:27:53:30:E5:CB   
