{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.245:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:32.764Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "172.31.250.55:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:32.765Z",
  "value": "(localhost)"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:36.949Z",
  "value": "id=792   sec_id=4     flags=0x0000 ifindex=9   mac=AA:5A:43:1B:76:66 nodemac=F6:AF:35:4F:6A:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:36.977Z",
  "value": "id=792   sec_id=4     flags=0x0000 ifindex=9   mac=AA:5A:43:1B:76:66 nodemac=F6:AF:35:4F:6A:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:44.360Z",
  "value": "id=792   sec_id=4     flags=0x0000 ifindex=9   mac=AA:5A:43:1B:76:66 nodemac=F6:AF:35:4F:6A:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:44.387Z",
  "value": "id=24    sec_id=7887282 flags=0x0000 ifindex=11  mac=E2:1F:47:0C:F0:76 nodemac=6A:27:53:30:E5:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:45.360Z",
  "value": "id=24    sec_id=7887282 flags=0x0000 ifindex=11  mac=E2:1F:47:0C:F0:76 nodemac=6A:27:53:30:E5:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:45.361Z",
  "value": "id=792   sec_id=4     flags=0x0000 ifindex=9   mac=AA:5A:43:1B:76:66 nodemac=F6:AF:35:4F:6A:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:14:59.360Z",
  "value": "id=61    sec_id=7887282 flags=0x0000 ifindex=13  mac=CA:29:1D:ED:FF:A0 nodemac=9E:74:6D:A2:2C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:19.830Z",
  "value": "id=792   sec_id=4     flags=0x0000 ifindex=9   mac=AA:5A:43:1B:76:66 nodemac=F6:AF:35:4F:6A:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:19.830Z",
  "value": "id=24    sec_id=7887282 flags=0x0000 ifindex=11  mac=E2:1F:47:0C:F0:76 nodemac=6A:27:53:30:E5:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:19.831Z",
  "value": "id=61    sec_id=7887282 flags=0x0000 ifindex=13  mac=CA:29:1D:ED:FF:A0 nodemac=9E:74:6D:A2:2C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:19.862Z",
  "value": "id=176   sec_id=7891667 flags=0x0000 ifindex=15  mac=CE:81:53:A2:EC:79 nodemac=D6:67:88:C3:2A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:20.830Z",
  "value": "id=61    sec_id=7887282 flags=0x0000 ifindex=13  mac=CA:29:1D:ED:FF:A0 nodemac=9E:74:6D:A2:2C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:20.830Z",
  "value": "id=24    sec_id=7887282 flags=0x0000 ifindex=11  mac=E2:1F:47:0C:F0:76 nodemac=6A:27:53:30:E5:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:20.830Z",
  "value": "id=176   sec_id=7891667 flags=0x0000 ifindex=15  mac=CE:81:53:A2:EC:79 nodemac=D6:67:88:C3:2A:C6"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:15:20.831Z",
  "value": "id=792   sec_id=4     flags=0x0000 ifindex=9   mac=AA:5A:43:1B:76:66 nodemac=F6:AF:35:4F:6A:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:02.661Z",
  "value": "id=1511  sec_id=7891667 flags=0x0000 ifindex=17  mac=D6:34:58:85:AD:61 nodemac=E2:AD:F9:34:94:BE"
}

{
  "action": "delete",
  "desired-action": "to-be-deleted",
  "key": "10.119.0.94:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:07.851Z",
  "value": "\u003cnil\u003e"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:29.817Z",
  "value": "id=1511  sec_id=7891667 flags=0x0000 ifindex=17  mac=D6:34:58:85:AD:61 nodemac=E2:AD:F9:34:94:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:29.818Z",
  "value": "id=792   sec_id=4     flags=0x0000 ifindex=9   mac=AA:5A:43:1B:76:66 nodemac=F6:AF:35:4F:6A:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:29.819Z",
  "value": "id=24    sec_id=7887282 flags=0x0000 ifindex=11  mac=E2:1F:47:0C:F0:76 nodemac=6A:27:53:30:E5:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:29.819Z",
  "value": "id=61    sec_id=7887282 flags=0x0000 ifindex=13  mac=CA:29:1D:ED:FF:A0 nodemac=9E:74:6D:A2:2C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:30.810Z",
  "value": "id=61    sec_id=7887282 flags=0x0000 ifindex=13  mac=CA:29:1D:ED:FF:A0 nodemac=9E:74:6D:A2:2C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:30.810Z",
  "value": "id=1511  sec_id=7891667 flags=0x0000 ifindex=17  mac=D6:34:58:85:AD:61 nodemac=E2:AD:F9:34:94:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:30.810Z",
  "value": "id=792   sec_id=4     flags=0x0000 ifindex=9   mac=AA:5A:43:1B:76:66 nodemac=F6:AF:35:4F:6A:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:30.811Z",
  "value": "id=24    sec_id=7887282 flags=0x0000 ifindex=11  mac=E2:1F:47:0C:F0:76 nodemac=6A:27:53:30:E5:CB"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.11:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:31.811Z",
  "value": "id=61    sec_id=7887282 flags=0x0000 ifindex=13  mac=CA:29:1D:ED:FF:A0 nodemac=9E:74:6D:A2:2C:CC"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.174:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:31.811Z",
  "value": "id=1511  sec_id=7891667 flags=0x0000 ifindex=17  mac=D6:34:58:85:AD:61 nodemac=E2:AD:F9:34:94:BE"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.129:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:31.811Z",
  "value": "id=792   sec_id=4     flags=0x0000 ifindex=9   mac=AA:5A:43:1B:76:66 nodemac=F6:AF:35:4F:6A:2B"
}

{
  "action": "update",
  "desired-action": "sync",
  "key": "10.119.0.35:0",
  "last-error": "\u003cnil\u003e",
  "timestamp": "2024-10-25T10:23:31.811Z",
  "value": "id=24    sec_id=7887282 flags=0x0000 ifindex=11  mac=E2:1F:47:0C:F0:76 nodemac=6A:27:53:30:E5:CB"
}

