markdown output at /tmp/cilium-bugtool-20241025-102841.596+0000-UTC-1670195103/cmd/cilium-debuginfo-20241025-102912.313+0000-UTC.md
json output at /tmp/cilium-bugtool-20241025-102841.596+0000-UTC-1670195103/cmd/cilium-debuginfo-20241025-102912.313+0000-UTC.json
