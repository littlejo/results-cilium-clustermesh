Endpoint ID: 24
Path: /sys/fs/bpf/tc/globals/cilium_policy_00024

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    80457   920       0        
Allow    Egress      0          ANY          NONE         disabled    13962   147       0        


Endpoint ID: 61
Path: /sys/fs/bpf/tc/globals/cilium_policy_00061

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    81608   941       0        
Allow    Egress      0          ANY          NONE         disabled    13144   135       0        


Endpoint ID: 381
Path: /sys/fs/bpf/tc/globals/cilium_policy_00381

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 792
Path: /sys/fs/bpf/tc/globals/cilium_policy_00792

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES    PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    431532   5492      0        
Allow    Ingress     1          ANY          NONE         disabled    11994    139       0        
Allow    Egress      0          ANY          NONE         disabled    0        0         0        


Endpoint ID: 1511
Path: /sys/fs/bpf/tc/globals/cilium_policy_01511

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3859333   35401     0        
Allow    Ingress     1          ANY          NONE         disabled    2819159   28261     0        
Allow    Egress      0          ANY          NONE         disabled    3697708   34498     0        


